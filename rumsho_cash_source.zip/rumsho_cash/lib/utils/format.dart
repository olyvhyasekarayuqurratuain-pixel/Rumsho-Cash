import 'package:intl/intl.dart';

final NumberFormat _plain = NumberFormat.decimalPattern('id_ID');

/// 15000 -> "15.000"
String rupiahPlain(num v) => _plain.format(v);

/// 15000 -> "Rp 15.000" (spasi biasa, aman untuk printer thermal)
String rupiah(num v) => 'Rp ${rupiahPlain(v)}';

String tanggal(DateTime d) => DateFormat('dd MMM yyyy, HH:mm', 'id_ID').format(d);
String tanggalAngka(DateTime d) => DateFormat('dd/MM/yyyy HH:mm').format(d);
String tanggalHari(DateTime d) => DateFormat('EEE, dd MMM yyyy', 'id_ID').format(d);
String tanggalFile(DateTime d) => DateFormat('yyyyMMdd').format(d);

/// Ambil angka saja dari teks input ("Rp 15.000" -> 15000).
int parseRupiah(String s) => int.tryParse(s.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
