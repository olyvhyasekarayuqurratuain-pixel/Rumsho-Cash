import 'dart:math';

import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/product.dart';
import '../models/sale.dart';
import '../models/shipment.dart';

class StockMove {
  final int id;
  final int productId;
  final int delta;
  final int stockAfter;
  final String reason;
  final DateTime createdAt;

  const StockMove({
    required this.id,
    required this.productId,
    required this.delta,
    required this.stockAfter,
    required this.reason,
    required this.createdAt,
  });

  factory StockMove.fromMap(Map<String, Object?> m) => StockMove(
        id: m['id'] as int,
        productId: m['product_id'] as int,
        delta: m['delta'] as int,
        stockAfter: m['stock_after'] as int,
        reason: (m['reason'] as String?) ?? '',
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

/// Seluruh data tersimpan lokal di SQLite (file rumsho_cash.db) — tanpa internet.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;
  Future<Database> get database async => _db ??= await _open();

  static const List<String> _schema = [
    '''CREATE TABLE products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      barcode TEXT NOT NULL UNIQUE,
      price INTEGER NOT NULL DEFAULT 0,
      cost INTEGER NOT NULL DEFAULT 0,
      stock INTEGER NOT NULL DEFAULT 0,
      min_stock INTEGER NOT NULL DEFAULT 5,
      photo_path TEXT,
      created_at TEXT NOT NULL
    )''',
    '''CREATE TABLE sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      subtotal INTEGER NOT NULL,
      discount INTEGER NOT NULL DEFAULT 0,
      total INTEGER NOT NULL,
      paid INTEGER NOT NULL,
      change_amount INTEGER NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL,
      customer_name TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      voided INTEGER NOT NULL DEFAULT 0
    )''',
    '''CREATE TABLE sale_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
      product_id INTEGER,
      name TEXT NOT NULL,
      barcode TEXT NOT NULL DEFAULT '',
      qty INTEGER NOT NULL,
      price INTEGER NOT NULL,
      cost INTEGER NOT NULL DEFAULT 0
    )''',
    'CREATE INDEX idx_sales_created ON sales(created_at)',
    'CREATE INDEX idx_items_sale ON sale_items(sale_id)',
    '''CREATE TABLE stock_moves(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      delta INTEGER NOT NULL,
      stock_after INTEGER NOT NULL,
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    )''',
    'CREATE INDEX idx_moves_product ON stock_moves(product_id)',
    '''CREATE TABLE shipments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at TEXT NOT NULL,
      sender_name TEXT NOT NULL DEFAULT '',
      sender_phone TEXT NOT NULL DEFAULT '',
      sender_address TEXT NOT NULL DEFAULT '',
      receiver_name TEXT NOT NULL DEFAULT '',
      receiver_phone TEXT NOT NULL DEFAULT '',
      receiver_address TEXT NOT NULL DEFAULT '',
      courier TEXT NOT NULL DEFAULT '',
      tracking_no TEXT NOT NULL DEFAULT '',
      item_desc TEXT NOT NULL DEFAULT '',
      weight_gram INTEGER NOT NULL DEFAULT 0,
      cod_amount INTEGER NOT NULL DEFAULT 0,
      note TEXT NOT NULL DEFAULT ''
    )''',
  ];

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'rumsho_cash.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        for (final sql in _schema) {
          await db.execute(sql);
        }
      },
    );
  }

  // ------------------------------------------------------------ PRODUK

  Future<List<Product>> products({String query = ''}) async {
    final d = await database;
    final q = query.trim();
    final rows = await d.query(
      'products',
      where: q.isEmpty ? null : 'name LIKE ? OR barcode LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Product.fromMap).toList();
  }

  Future<Product?> productByBarcode(String code) async {
    final d = await database;
    final rows = await d.query('products',
        where: 'barcode = ?', whereArgs: [code], limit: 1);
    return rows.isEmpty ? null : Product.fromMap(rows.first);
  }

  Future<String> generateBarcode() async {
    final d = await database;
    final rnd = Random();
    while (true) {
      final code = 'RC${List.generate(8, (_) => rnd.nextInt(10)).join()}';
      final r = await d.query('products',
          columns: ['id'], where: 'barcode = ?', whereArgs: [code], limit: 1);
      if (r.isEmpty) return code;
    }
  }

  Future<int> insertProduct(Product product) async {
    final d = await database;
    return d.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      final id = await txn.insert('products', {
        ...product.toMap(),
        'created_at': now,
      });
      if (product.stock != 0) {
        await txn.insert('stock_moves', {
          'product_id': id,
          'delta': product.stock,
          'stock_after': product.stock,
          'reason': 'Stok awal',
          'created_at': now,
        });
      }
      return id;
    });
  }

  /// Memperbarui data barang (stok TIDAK diubah di sini; gunakan [adjustStock]).
  Future<void> updateProduct(Product product) async {
    final d = await database;
    final m = product.toMap()
      ..remove('id')
      ..remove('stock');
    await d.update('products', m, where: 'id = ?', whereArgs: [product.id]);
  }

  Future<void> deleteProduct(int id) async {
    final d = await database;
    await d.transaction((txn) async {
      await txn.delete('stock_moves', where: 'product_id = ?', whereArgs: [id]);
      await txn.delete('products', where: 'id = ?', whereArgs: [id]);
    });
  }

  // ------------------------------------------------------------ STOK

  Future<void> _moveStock(
      DatabaseExecutor txn, int productId, int delta, String reason) async {
    final r = await txn.query('products',
        columns: ['stock'], where: 'id = ?', whereArgs: [productId], limit: 1);
    if (r.isEmpty) return;
    final next = (r.first['stock'] as int) + delta;
    await txn.update('products', {'stock': next},
        where: 'id = ?', whereArgs: [productId]);
    await txn.insert('stock_moves', {
      'product_id': productId,
      'delta': delta,
      'stock_after': next,
      'reason': reason,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  /// Set stok ke angka tertentu (restock / koreksi / stok opname).
  Future<void> adjustStock(int productId,
      {required int newStock, required String reason}) async {
    final d = await database;
    await d.transaction((txn) async {
      final r = await txn.query('products',
          columns: ['stock'], where: 'id = ?', whereArgs: [productId], limit: 1);
      if (r.isEmpty) return;
      final cur = r.first['stock'] as int;
      if (cur == newStock) return;
      await _moveStock(txn, productId, newStock - cur, reason);
    });
  }

  Future<List<StockMove>> stockMoves(int productId, {int limit = 100}) async {
    final d = await database;
    final rows = await d.query('stock_moves',
        where: 'product_id = ?',
        whereArgs: [productId],
        orderBy: 'id DESC',
        limit: limit);
    return rows.map(StockMove.fromMap).toList();
  }

  // ------------------------------------------------------------ PENJUALAN

  /// Menyimpan transaksi + mengurangi stok + mencatat mutasi stok, dalam 1 transaksi DB.
  Future<Sale> insertSale(Sale sale) async {
    final d = await database;
    return d.transaction((txn) async {
      final now = sale.createdAt;
      final dayStart = DateTime(now.year, now.month, now.day);
      final count = Sqflite.firstIntValue(await txn.rawQuery(
              'SELECT COUNT(*) FROM sales WHERE created_at >= ?',
              [dayStart.toIso8601String()])) ??
          0;
      final inv =
          'INV-${DateFormat('yyMMdd').format(now)}-${(count + 1).toString().padLeft(4, '0')}';
      final saved = sale.copyWith(invoiceNo: inv);
      final id = await txn.insert('sales', saved.toMap());
      for (final it in saved.items) {
        await txn.insert('sale_items', it.toMap(id));
        if (it.productId != null) {
          await _moveStock(txn, it.productId!, -it.qty, 'Penjualan $inv');
        }
      }
      return saved.copyWith(id: id);
    });
  }

  /// Membatalkan transaksi: stok dikembalikan, transaksi ditandai batal.
  Future<void> voidSale(int saleId) async {
    final d = await database;
    await d.transaction((txn) async {
      final rows = await txn.query('sales',
          where: 'id = ?', whereArgs: [saleId], limit: 1);
      if (rows.isEmpty || (rows.first['voided'] as int) == 1) return;
      final inv = rows.first['invoice_no'] as String;
      await txn.update('sales', {'voided': 1},
          where: 'id = ?', whereArgs: [saleId]);
      final items = await txn
          .query('sale_items', where: 'sale_id = ?', whereArgs: [saleId]);
      for (final it in items) {
        final pid = it['product_id'] as int?;
        if (pid == null) continue;
        await _moveStock(txn, pid, it['qty'] as int, 'Batal $inv');
      }
    });
  }

  /// [from] inklusif, [to] eksklusif.
  Future<List<Sale>> sales({
    DateTime? from,
    DateTime? to,
    bool includeVoided = true,
    int? limit,
  }) async {
    final d = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (from != null) {
      where.add('created_at >= ?');
      args.add(from.toIso8601String());
    }
    if (to != null) {
      where.add('created_at < ?');
      args.add(to.toIso8601String());
    }
    if (!includeVoided) where.add('voided = 0');

    final rows = await d.query(
      'sales',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'created_at DESC',
      limit: limit,
    );
    if (rows.isEmpty) return [];

    final ids = rows.map((r) => r['id'] as int).toList();
    final byId = <int, List<SaleItem>>{};
    const chunk = 500;
    for (var i = 0; i < ids.length; i += chunk) {
      final part = ids.sublist(i, min(i + chunk, ids.length));
      final itemRows = await d.query(
        'sale_items',
        where: 'sale_id IN (${List.filled(part.length, '?').join(',')})',
        whereArgs: part,
        orderBy: 'id',
      );
      for (final r in itemRows) {
        byId
            .putIfAbsent(r['sale_id'] as int, () => [])
            .add(SaleItem.fromMap(r));
      }
    }
    return rows
        .map((r) => Sale.fromMap(r, byId[r['id'] as int] ?? const []))
        .toList();
  }

  // ------------------------------------------------------------ RESI

  Future<int> insertShipment(Shipment s) async {
    final d = await database;
    return d.insert('shipments', s.toMap());
  }

  Future<void> updateShipment(Shipment s) async {
    final d = await database;
    await d.update('shipments', s.toMap(), where: 'id = ?', whereArgs: [s.id]);
  }

  Future<void> deleteShipment(int id) async {
    final d = await database;
    await d.delete('shipments', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Shipment>> shipments({int limit = 300}) async {
    final d = await database;
    final rows = await d.query('shipments', orderBy: 'id DESC', limit: limit);
    return rows.map(Shipment.fromMap).toList();
  }
}
