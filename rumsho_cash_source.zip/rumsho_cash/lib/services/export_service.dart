import 'package:excel/excel.dart';

import '../models/product.dart';
import '../models/sale.dart';
import '../models/store_settings.dart';
import '../utils/format.dart';
import 'share_service.dart';

const _xlsxMime =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

/// Export laporan ke file Excel (.xlsx), dibuat langsung di perangkat (offline).
/// Hasilnya dibuka lewat menu bagikan agar bisa disimpan ke Files/Drive/WhatsApp.
class ExportService {
  static CellValue? _cv(Object? v) {
    if (v == null) return null;
    if (v is int) return IntCellValue(v);
    if (v is double) return DoubleCellValue(v);
    return TextCellValue(v.toString());
  }

  static void _row(Sheet s, List<Object?> values, {bool bold = false}) {
    s.appendRow(values.map(_cv).toList());
    if (bold) {
      final r = s.maxRows - 1;
      for (var c = 0; c < values.length; c++) {
        s
            .cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: r))
            .cellStyle = CellStyle(bold: true);
      }
    }
  }

  static void _widths(Sheet s, List<double> widths) {
    for (var i = 0; i < widths.length; i++) {
      s.setColumnWidth(i, widths[i]);
    }
  }

  /// [sales] sebaiknya hanya transaksi yang tidak dibatalkan.
  static Future<void> exportSales({
    required List<Sale> sales,
    required DateTime from,
    required DateTime toInclusive,
    required StoreSettings settings,
  }) async {
    final excel = Excel.createExcel();
    final ringkasan = excel['Ringkasan'];
    final transaksi = excel['Transaksi'];
    final detail = excel['Detail Item'];
    final terlaris = excel['Produk Terlaris'];

    final omzet = sales.fold<int>(0, (a, s) => a + s.total);
    final laba = sales.fold<int>(0, (a, s) => a + s.profit);
    final item = sales.fold<int>(0, (a, s) => a + s.itemCount);

    // --- Ringkasan
    _row(ringkasan, ['LAPORAN PENJUALAN'], bold: true);
    _row(ringkasan, [settings.name.isEmpty ? 'Rumsho Cash' : settings.name]);
    _row(ringkasan, ['Periode', '${tanggalHari(from)} s/d ${tanggalHari(toInclusive)}']);
    _row(ringkasan, []);
    _row(ringkasan, ['Omzet (Rp)', omzet], bold: true);
    _row(ringkasan, ['Laba / Keuntungan (Rp)', laba], bold: true);
    _row(ringkasan, ['Jumlah Transaksi', sales.length]);
    _row(ringkasan, ['Item Terjual', item]);
    _row(ringkasan, [
      'Rata-rata per Transaksi (Rp)',
      sales.isEmpty ? 0 : (omzet / sales.length).round()
    ]);
    _row(ringkasan, []);
    _row(ringkasan, ['Metode Bayar', 'Transaksi', 'Total (Rp)'], bold: true);
    final byMethod = <String, List<int>>{};
    for (final s in sales) {
      final e = byMethod.putIfAbsent(s.paymentMethod, () => [0, 0]);
      e[0] += 1;
      e[1] += s.total;
    }
    byMethod.forEach((k, v) => _row(ringkasan, [k, v[0], v[1]]));
    _widths(ringkasan, [30, 28, 16]);

    // --- Transaksi
    _row(
        transaksi,
        [
          'No Invoice',
          'Tanggal',
          'Pelanggan',
          'Metode',
          'Subtotal',
          'Diskon',
          'Total',
          'Bayar',
          'Kembali',
          'Laba',
        ],
        bold: true);
    for (final s in sales.reversed) {
      _row(transaksi, [
        s.invoiceNo,
        tanggalAngka(s.createdAt),
        s.customerName,
        s.paymentMethod,
        s.subtotal,
        s.discount,
        s.total,
        s.paid,
        s.change,
        s.profit,
      ]);
    }
    _widths(transaksi, [20, 18, 20, 12, 12, 10, 12, 12, 12, 12]);

    // --- Detail item
    _row(
        detail,
        [
          'No Invoice',
          'Tanggal',
          'Produk',
          'Barcode',
          'Qty',
          'Harga',
          'Modal',
          'Subtotal',
          'Laba',
        ],
        bold: true);
    final top = <String, List<Object>>{}; // key -> [nama, qty, omzet, laba]
    for (final s in sales.reversed) {
      for (final it in s.items) {
        _row(detail, [
          s.invoiceNo,
          tanggalAngka(s.createdAt),
          it.name,
          it.barcode,
          it.qty,
          it.price,
          it.cost,
          it.subtotal,
          it.profit,
        ]);
        final e = top.putIfAbsent(
            '${it.barcode}|${it.name}', () => [it.name, 0, 0, 0]);
        e[1] = (e[1] as int) + it.qty;
        e[2] = (e[2] as int) + it.subtotal;
        e[3] = (e[3] as int) + it.profit;
      }
    }
    _widths(detail, [20, 18, 28, 16, 8, 12, 12, 12, 12]);

    // --- Produk terlaris
    _row(terlaris, ['Produk', 'Qty Terjual', 'Omzet (Rp)', 'Laba (Rp)'],
        bold: true);
    final topList = top.values.toList()
      ..sort((a, b) => (b[1] as int).compareTo(a[1] as int));
    for (final e in topList) {
      _row(terlaris, [e[0], e[1], e[2], e[3]]);
    }
    _widths(terlaris, [30, 14, 14, 14]);

    if (excel.sheets.containsKey('Sheet1')) excel.delete('Sheet1');

    final bytes = excel.save();
    if (bytes == null) throw Exception('Gagal membuat file Excel');
    await ShareService.shareFile(
      bytes,
      'Laporan_Penjualan_${tanggalFile(from)}_${tanggalFile(toInclusive)}.xlsx',
      mimeType: _xlsxMime,
      subject: 'Laporan Penjualan',
    );
  }

  static Future<void> exportStock(
      List<Product> products, StoreSettings settings) async {
    final excel = Excel.createExcel();
    final s = excel['Stok Barang'];
    _row(
        s,
        [
          'Nama Produk',
          'Barcode/QR',
          'Stok',
          'Batas Menipis',
          'Harga Modal',
          'Harga Jual',
          'Nilai Modal',
          'Nilai Jual',
        ],
        bold: true);
    for (final p in products) {
      _row(s, [
        p.name,
        p.barcode,
        p.stock,
        p.minStock,
        p.cost,
        p.price,
        p.stock * p.cost,
        p.stock * p.price,
      ]);
    }
    _row(s, []);
    _row(
        s,
        [
          'TOTAL',
          '',
          products.fold<int>(0, (a, p) => a + p.stock),
          '',
          '',
          '',
          products.fold<int>(0, (a, p) => a + p.stock * p.cost),
          products.fold<int>(0, (a, p) => a + p.stock * p.price),
        ],
        bold: true);
    _widths(s, [30, 18, 8, 14, 14, 14, 16, 16]);

    if (excel.sheets.containsKey('Sheet1')) excel.delete('Sheet1');

    final bytes = excel.save();
    if (bytes == null) throw Exception('Gagal membuat file Excel');
    await ShareService.shareFile(
      bytes,
      'Stok_Barang_${tanggalFile(DateTime.now())}.xlsx',
      mimeType: _xlsxMime,
      subject: 'Stok Barang',
    );
  }
}
