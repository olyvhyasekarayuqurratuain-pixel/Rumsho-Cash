import 'package:barcode/barcode.dart';
import 'package:image/image.dart' as img;

/// Menggambar Barcode (Code128) atau QR menjadi gambar hitam-putih,
/// supaya bisa dicetak di printer thermal sebagai bitmap (paling kompatibel
/// di semua merek printer).
img.Image renderCodeImage(
  String data, {
  required bool qr,
  required int width,
  required int height,
  int margin = 6,
}) {
  final bc = qr ? Barcode.qrCode() : Barcode.code128();
  final canvas = img.Image(width: width, height: height);
  img.fill(canvas, color: img.ColorRgb8(255, 255, 255));

  final w = (width - margin * 2).toDouble();
  final h = (height - margin * 2).toDouble();

  for (final el in bc.make(data, width: w, height: h)) {
    if (el is BarcodeBar && el.black) {
      final x1 = (el.left + margin).round();
      final x2 = (el.left + el.width + margin).round() - 1;
      final y1 = (el.top + margin).round();
      final y2 = (el.top + el.height + margin).round() - 1;
      for (var y = y1; y <= y2; y++) {
        if (y < 0 || y >= height) continue;
        for (var x = x1; x <= x2; x++) {
          if (x < 0 || x >= width) continue;
          canvas.setPixelRgb(x, y, 0, 0, 0);
        }
      }
    }
  }
  return canvas;
}

/// Apakah [data] valid untuk Code128 (karakter ASCII).
bool isValidCode128(String data) =>
    data.isNotEmpty && Barcode.code128().isValid(data);
