import 'dart:io';

import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:image/image.dart' as img;
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';

import '../models/product.dart';
import '../models/sale.dart';
import '../models/shipment.dart';
import '../models/store_settings.dart';
import '../utils/format.dart';
import 'barcode_raster.dart';

class PrintResult {
  final bool ok;
  final String message;
  const PrintResult(this.ok, this.message);
}

/// Cetak ke printer thermal Bluetooth (ESC/POS): struk, label barcode/QR,
/// resi pengiriman, dan buka cash drawer (lewat port RJ11 printer).
class PrinterService {
  PrinterService._();
  static final PrinterService instance = PrinterService._();

  static const _center = PosStyles(align: PosAlign.center);
  static const _centerBold = PosStyles(align: PosAlign.center, bold: true);
  static const _big = PosStyles(
    align: PosAlign.center,
    bold: true,
    height: PosTextSize.size2,
    width: PosTextSize.size2,
  );

  // ------------------------------------------------------------ KONEKSI

  Future<bool> ensurePermissions() async {
    try {
      await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
    } catch (_) {}
    return PrintBluetoothThermal.isPermissionBluetoothGranted;
  }

  Future<List<BluetoothInfo>> pairedDevices() =>
      PrintBluetoothThermal.pairedBluetooths;

  Future<bool> isConnected() => PrintBluetoothThermal.connectionStatus;

  Future<bool> connect(String mac) =>
      PrintBluetoothThermal.connect(macPrinterAddress: mac);

  Future<bool> disconnect() => PrintBluetoothThermal.disconnect;

  Future<bool> _ensureConnected(StoreSettings s) async {
    if (await isConnected()) return true;
    if (s.printerMac.isEmpty) return false;
    return connect(s.printerMac);
  }

  Future<bool> _send(List<int> bytes) async {
    const chunk = 900;
    for (var i = 0; i < bytes.length; i += chunk) {
      final end = (i + chunk < bytes.length) ? i + chunk : bytes.length;
      final ok = await PrintBluetoothThermal.writeBytes(bytes.sublist(i, end));
      if (!ok) return false;
      await Future.delayed(const Duration(milliseconds: 30));
    }
    return true;
  }

  /// Kirim data mentah ESC/POS ke printer (konek otomatis jika perlu).
  Future<PrintResult> printBytes(List<int> bytes, StoreSettings s) async {
    if (!await ensurePermissions()) {
      return const PrintResult(false, 'Izin Bluetooth belum diberikan.');
    }
    if (!await PrintBluetoothThermal.bluetoothEnabled) {
      return const PrintResult(false, 'Bluetooth belum aktif.');
    }
    if (!await _ensureConnected(s)) {
      return PrintResult(
          false,
          s.printerMac.isEmpty
              ? 'Printer belum dipilih. Buka Menu > Printer Bluetooth.'
              : 'Gagal terhubung ke ${s.printerName}. Pastikan printer menyala & dekat.');
    }
    final ok = await _send(bytes);
    return ok
        ? const PrintResult(true, 'Berhasil dicetak')
        : const PrintResult(false, 'Gagal mengirim data ke printer.');
  }

  // ------------------------------------------------------------ UTIL

  Future<Generator> _gen(StoreSettings s) async {
    final profile = await CapabilityProfile.load();
    return Generator(s.paperMm == 80 ? PaperSize.mm80 : PaperSize.mm58, profile);
  }

  int _dots(StoreSettings s) => s.paperMm == 80 ? 576 : 384;

  /// Printer thermal murah sering tidak mendukung karakter non-ASCII.
  String _a(String v) => v.replaceAll(RegExp(r'[^\x20-\x7E]'), '?');

  List<String> _lines(String v) =>
      v.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

  List<int> _pair(Generator g, String l, String r, {bool bold = false}) =>
      g.row([
        PosColumn(text: _a(l), width: 6, styles: PosStyles(bold: bold)),
        PosColumn(
            text: _a(r),
            width: 6,
            styles: PosStyles(align: PosAlign.right, bold: bold)),
      ]);

  List<int> _logo(Generator g, StoreSettings s) {
    if (s.logoPath.isEmpty) return [];
    final f = File(s.logoPath);
    if (!f.existsSync()) return [];
    final src = img.decodeImage(f.readAsBytesSync());
    if (src == null) return [];
    final maxW = s.paperMm == 80 ? 300 : 220;
    final scaled = src.width > maxW ? img.copyResize(src, width: maxW) : src;
    // Ratakan transparansi ke latar putih agar logo PNG tidak jadi blok hitam.
    final canvas = img.Image(width: scaled.width, height: scaled.height);
    img.fill(canvas, color: img.ColorRgb8(255, 255, 255));
    img.compositeImage(canvas, scaled);
    return g.image(canvas);
  }

  // ------------------------------------------------------------ STRUK

  Future<List<int>> buildReceipt(Sale sale, StoreSettings s,
      {bool openDrawer = false}) async {
    final g = await _gen(s);
    final b = <int>[];
    b.addAll(g.reset());
    if (openDrawer) b.addAll(g.drawer());

    b.addAll(_logo(g, s));
    if (s.name.isNotEmpty) b.addAll(g.text(_a(s.name), styles: _big));
    for (final l in _lines(s.address)) {
      b.addAll(g.text(_a(l), styles: _center));
    }
    if (s.phone.isNotEmpty) {
      b.addAll(g.text(_a('Telp: ${s.phone}'), styles: _center));
    }
    b.addAll(g.hr());

    b.addAll(g.text(_a('No  : ${sale.invoiceNo}')));
    b.addAll(g.text('Tgl : ${tanggalAngka(sale.createdAt)}'));
    if (sale.customerName.isNotEmpty) {
      b.addAll(g.text(_a('Plg : ${sale.customerName}')));
    }
    b.addAll(g.hr());

    for (final it in sale.items) {
      b.addAll(g.text(_a(it.name), styles: const PosStyles(bold: true)));
      b.addAll(g.row([
        PosColumn(text: '${it.qty} x ${rupiahPlain(it.price)}', width: 7),
        PosColumn(
            text: rupiahPlain(it.subtotal),
            width: 5,
            styles: const PosStyles(align: PosAlign.right)),
      ]));
    }
    b.addAll(g.hr());

    b.addAll(_pair(g, 'Subtotal', rupiahPlain(sale.subtotal)));
    if (sale.discount > 0) {
      b.addAll(_pair(g, 'Diskon', '-${rupiahPlain(sale.discount)}'));
    }
    b.addAll(_pair(g, 'TOTAL', rupiahPlain(sale.total), bold: true));
    b.addAll(_pair(g, 'Bayar (${sale.paymentMethod})', rupiahPlain(sale.paid)));
    if (sale.paymentMethod == 'Tunai') {
      b.addAll(_pair(g, 'Kembali', rupiahPlain(sale.change)));
    }
    b.addAll(g.hr());

    for (final l in _lines(s.footnote)) {
      b.addAll(g.text(_a(l), styles: _center));
    }
    b.addAll(g.text('Terima kasih', styles: _centerBold));
    b.addAll(g.feed(3));
    return b;
  }

  // ------------------------------------------------------------ LABEL BARCODE / QR

  Future<List<int>> buildLabel(Product p, StoreSettings s,
      {bool qr = false, int copies = 1}) async {
    final g = await _gen(s);
    final b = <int>[];
    b.addAll(g.reset());
    final wide = _dots(s) >= 576;
    for (var i = 0; i < copies; i++) {
      b.addAll(g.text(_a(p.name), styles: _centerBold));
      b.addAll(g.text('Rp ${rupiahPlain(p.price)}', styles: _big));
      final image = qr
          ? renderCodeImage(p.barcode, qr: true, width: 200, height: 200)
          : renderCodeImage(p.barcode,
              qr: false, width: wide ? 460 : 340, height: 90);
      b.addAll(g.image(image));
      b.addAll(g.text(_a(p.barcode), styles: _center));
      b.addAll(g.feed(2));
    }
    return b;
  }

  // ------------------------------------------------------------ RESI PENGIRIMAN

  Future<List<int>> buildShipment(Shipment sh, StoreSettings s) async {
    final g = await _gen(s);
    final b = <int>[];
    b.addAll(g.reset());

    b.addAll(g.text('RESI PENGIRIMAN', styles: _big));
    if (s.name.isNotEmpty) b.addAll(g.text(_a(s.name), styles: _center));
    b.addAll(g.hr());

    b.addAll(_pair(g, 'Kurir: ${sh.courier.isEmpty ? '-' : sh.courier}',
        sh.weightGram > 0 ? 'Berat: ${sh.weightGram} g' : ''));

    final code = sh.trackingNo.isNotEmpty
        ? sh.trackingNo
        : 'RSH${(sh.id ?? 0).toString().padLeft(6, '0')}';
    if (isValidCode128(code)) {
      final wide = _dots(s) >= 576;
      b.addAll(g.image(renderCodeImage(code,
          qr: false, width: wide ? 460 : 340, height: 80)));
    }
    b.addAll(g.text(_a(code), styles: _center));
    b.addAll(g.hr());

    b.addAll(g.text('PENERIMA', styles: const PosStyles(bold: true)));
    b.addAll(g.text(_a(sh.receiverName),
        styles: const PosStyles(
            bold: true, height: PosTextSize.size2, width: PosTextSize.size1)));
    if (sh.receiverPhone.isNotEmpty) b.addAll(g.text(_a(sh.receiverPhone)));
    for (final l in _lines(sh.receiverAddress)) {
      b.addAll(g.text(_a(l)));
    }
    b.addAll(g.hr());

    b.addAll(g.text('PENGIRIM', styles: const PosStyles(bold: true)));
    final senderName = sh.senderName.isNotEmpty ? sh.senderName : s.name;
    if (senderName.isNotEmpty) b.addAll(g.text(_a(senderName)));
    if (sh.senderPhone.isNotEmpty) b.addAll(g.text(_a(sh.senderPhone)));
    for (final l in _lines(sh.senderAddress)) {
      b.addAll(g.text(_a(l)));
    }
    b.addAll(g.hr());

    if (sh.itemDesc.isNotEmpty) {
      b.addAll(g.text(_a('Isi: ${sh.itemDesc}')));
    }
    if (sh.note.isNotEmpty) b.addAll(g.text(_a('Cat: ${sh.note}')));
    if (sh.codAmount > 0) {
      b.addAll(g.hr());
      b.addAll(g.text('COD', styles: _centerBold));
      b.addAll(g.text('Rp ${rupiahPlain(sh.codAmount)}', styles: _big));
    }
    b.addAll(g.text(tanggalAngka(sh.createdAt), styles: _center));
    b.addAll(g.feed(3));
    return b;
  }

  // ------------------------------------------------------------ LAIN-LAIN

  Future<List<int>> buildDrawer(StoreSettings s) async {
    final g = await _gen(s);
    return g.drawer();
  }

  Future<List<int>> buildTest(StoreSettings s) async {
    final g = await _gen(s);
    final b = <int>[];
    b.addAll(g.reset());
    b.addAll(g.text('RUMSHO CASH', styles: _big));
    b.addAll(g.text('Tes cetak berhasil', styles: _center));
    b.addAll(g.text('Kertas ${s.paperMm} mm', styles: _center));
    b.addAll(g.hr());
    b.addAll(g.text('0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ'));
    b.addAll(g.feed(3));
    return b;
  }
}
