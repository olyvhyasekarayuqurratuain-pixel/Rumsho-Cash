import 'dart:io';

import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';

import '../models/sale.dart';
import '../models/store_settings.dart';
import '../utils/format.dart';

/// Tampilan struk digital (logo, nama, alamat, item, total, catatan kaki).
/// Dibungkus RepaintBoundary di layar struk untuk dibagikan sebagai gambar.
class ReceiptView extends StatelessWidget {
  final Sale sale;
  final StoreSettings settings;
  const ReceiptView({super.key, required this.sale, required this.settings});

  Widget _dash() => const Padding(
        padding: EdgeInsets.symmetric(vertical: 6),
        child: Text('- - - - - - - - - - - - - - - - - - - -',
            maxLines: 1,
            softWrap: false,
            overflow: TextOverflow.clip,
            textAlign: TextAlign.center),
      );

  Widget _kv(String k, String v, {bool bold = false, double? size}) {
    final st = TextStyle(
        fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: size);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(k, style: st),
        const SizedBox(width: 12),
        Flexible(child: Text(v, style: st, textAlign: TextAlign.right)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = settings;
    final logo = s.logoPath.isNotEmpty && File(s.logoPath).existsSync()
        ? File(s.logoPath)
        : null;

    return Container(
      width: 340,
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(22, 26, 22, 26),
      child: DefaultTextStyle(
        style: const TextStyle(
            fontSize: 13,
            height: 1.35,
            color: Color(0xFF222222),
            fontFamily: 'monospace'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (logo != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Image.file(logo, height: 70, fit: BoxFit.contain),
              ),
            if (s.name.isNotEmpty)
              Text(s.name,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
            if (s.address.isNotEmpty)
              Text(s.address, textAlign: TextAlign.center),
            if (s.phone.isNotEmpty)
              Text('Telp: ${s.phone}', textAlign: TextAlign.center),
            _dash(),
            _kv('No', sale.invoiceNo),
            _kv('Tanggal', tanggalAngka(sale.createdAt)),
            if (sale.customerName.isNotEmpty)
              _kv('Pelanggan', sale.customerName),
            _dash(),
            for (final it in sale.items) ...[
              Text(it.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              _kv('${it.qty} x ${rupiahPlain(it.price)}',
                  rupiahPlain(it.subtotal)),
              const SizedBox(height: 4),
            ],
            _dash(),
            _kv('Subtotal', rupiahPlain(sale.subtotal)),
            if (sale.discount > 0)
              _kv('Diskon', '-${rupiahPlain(sale.discount)}'),
            _kv('TOTAL', rupiahPlain(sale.total), bold: true, size: 15),
            _kv('Bayar (${sale.paymentMethod})', rupiahPlain(sale.paid)),
            if (sale.paymentMethod == 'Tunai')
              _kv('Kembali', rupiahPlain(sale.change)),
            _dash(),
            if (s.footnote.isNotEmpty) ...[
              Text(s.footnote, textAlign: TextAlign.center),
              const SizedBox(height: 6),
            ],
            const Text('Terima kasih',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold)),
            if (sale.invoiceNo.isNotEmpty) ...[
              const SizedBox(height: 12),
              BarcodeWidget(
                barcode: Barcode.code128(),
                data: sale.invoiceNo,
                height: 44,
                drawText: false,
                color: Colors.black,
                errorBuilder: (context, error) => const SizedBox.shrink(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
