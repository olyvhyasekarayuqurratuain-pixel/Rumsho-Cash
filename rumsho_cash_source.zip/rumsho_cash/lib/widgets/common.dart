import 'dart:io';

import 'package:flutter/material.dart';

void showMessage(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirmDialog(
  BuildContext context,
  String title,
  String message, {
  String okLabel = 'Ya',
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Batal')),
        FilledButton(
            onPressed: () => Navigator.pop(c, true), child: Text(okLabel)),
      ],
    ),
  );
  return r ?? false;
}

class ProductThumb extends StatelessWidget {
  final String? path;
  final double size;
  const ProductThumb({super.key, this.path, this.size = 48});

  @override
  Widget build(BuildContext context) {
    final hasPhoto = path != null && path!.isNotEmpty && File(path!).existsSync();
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        width: size,
        height: size,
        child: hasPhoto
            ? Image.file(File(path!),
                fit: BoxFit.cover, cacheWidth: (size * 3).round())
            : ColoredBox(
                color: Colors.grey.shade200,
                child: Icon(Icons.inventory_2_outlined,
                    size: size * 0.45, color: Colors.grey.shade600),
              ),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color? color;
  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(children: [
              Icon(icon, size: 18, color: c),
              const SizedBox(width: 6),
              Expanded(
                  child: Text(label,
                      style: Theme.of(context).textTheme.labelMedium,
                      overflow: TextOverflow.ellipsis)),
            ]),
            const SizedBox(height: 8),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value,
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.bold, color: c)),
            ),
          ],
        ),
      ),
    );
  }
}
