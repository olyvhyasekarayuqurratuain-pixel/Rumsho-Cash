import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../screens/receipt_screen.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import 'common.dart';

/// Keranjang belanja + tombol bayar. Dipakai sebagai panel samping (tablet)
/// atau di dalam bottom sheet (HP).
class CartPanel extends StatelessWidget {
  final bool inSheet;
  const CartPanel({super.key, this.inSheet = false});

  Future<void> _discount(BuildContext context, AppState state) async {
    final ctrl = TextEditingController(
        text: state.discount > 0 ? '${state.discount}' : '');
    final v = await showDialog<int>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Diskon (Rp)'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(prefixText: 'Rp '),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('Batal')),
          FilledButton(
              onPressed: () => Navigator.pop(c, parseRupiah(ctrl.text)),
              child: const Text('Terapkan')),
        ],
      ),
    );
    if (v != null) state.setDiscount(v);
  }

  Future<void> _pay(BuildContext context) async {
    final nav = Navigator.of(context);
    final sale = await showDialog<Sale>(
        context: context, builder: (_) => const PaymentDialog());
    if (sale == null) return;
    if (inSheet) nav.pop();
    nav.push(MaterialPageRoute(
        builder: (_) => ReceiptScreen(sale: sale, justPaid: true)));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surface,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
            child: Row(children: [
              Text('Keranjang', style: theme.textTheme.titleMedium),
              const Spacer(),
              if (state.cart.isNotEmpty)
                TextButton.icon(
                  onPressed: state.clearCart,
                  icon: const Icon(Icons.delete_sweep_outlined, size: 18),
                  label: const Text('Kosongkan'),
                ),
            ]),
          ),
          const Divider(height: 1),
          Expanded(
            child: state.cart.isEmpty
                ? const Center(
                    child: Text('Belum ada barang.\nKetuk produk atau scan barcode.',
                        textAlign: TextAlign.center))
                : ListView.separated(
                    itemCount: state.cart.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final l = state.cart[i];
                      return ListTile(
                        dense: true,
                        title: Text(l.product.name,
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                            '${rupiah(l.product.price)}  x ${l.qty} = ${rupiah(l.subtotal)}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              icon: const Icon(Icons.remove_circle_outline),
                              onPressed: () => state.setQty(l, l.qty - 1),
                            ),
                            Text('${l.qty}',
                                style: theme.textTheme.titleSmall),
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              icon: const Icon(Icons.add_circle_outline),
                              onPressed: () {
                                final err = state.setQty(l, l.qty + 1);
                                if (err != null) showMessage(context, err);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Subtotal', style: theme.textTheme.bodyMedium),
                    Text(rupiah(state.cartSubtotal)),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton.icon(
                      style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                          minimumSize: const Size(0, 32)),
                      onPressed:
                          state.cart.isEmpty ? null : () => _discount(context, state),
                      icon: const Icon(Icons.sell_outlined, size: 18),
                      label: const Text('Diskon'),
                    ),
                    Text(state.discount > 0 ? '-${rupiah(state.discount)}' : '-'),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('TOTAL', style: theme.textTheme.titleMedium),
                    Text(rupiah(state.cartTotal),
                        style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: theme.colorScheme.primary)),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: state.cart.isEmpty ? null : () => _pay(context),
                    icon: const Icon(Icons.payments_outlined),
                    label: const Text('Bayar'),
                    style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PaymentDialog extends StatefulWidget {
  const PaymentDialog({super.key});

  @override
  State<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends State<PaymentDialog> {
  static const _methods = ['Tunai', 'QRIS', 'Transfer', 'Lainnya'];
  String _method = 'Tunai';
  final _paid = TextEditingController();
  final _customer = TextEditingController();
  final _note = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _paid.dispose();
    _customer.dispose();
    _note.dispose();
    super.dispose();
  }

  int _ceilTo(int v, int step) => ((v + step - 1) ~/ step) * step;

  Future<void> _submit(AppState state, int paid) async {
    setState(() => _busy = true);
    try {
      final sale = await state.checkout(
        method: _method,
        paid: paid,
        customer: _customer.text.trim(),
        note: _note.text.trim(),
      );
      if (mounted) Navigator.pop(context, sale);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showMessage(context, 'Gagal menyimpan transaksi: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final total = state.cartTotal;
    final cash = _method == 'Tunai';
    final paid = cash ? parseRupiah(_paid.text) : total;
    final enough = paid >= total;

    final quick = <int>{
      total,
      _ceilTo(total, 5000),
      _ceilTo(total, 10000),
      _ceilTo(total, 50000),
      _ceilTo(total, 100000),
    }.where((v) => v >= total && v > 0).toList()
      ..sort();

    return AlertDialog(
      title: const Text('Pembayaran'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Total tagihan', style: Theme.of(context).textTheme.labelMedium),
            Text(rupiah(total),
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final m in _methods)
                  ChoiceChip(
                    label: Text(m),
                    selected: _method == m,
                    onSelected: (_) => setState(() => _method = m),
                  ),
              ],
            ),
            if (cash) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _paid,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                    labelText: 'Uang diterima', prefixText: 'Rp '),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 0,
                children: [
                  for (final v in quick)
                    ActionChip(
                      label: Text(v == total ? 'Uang pas' : rupiahPlain(v)),
                      onPressed: () => setState(() => _paid.text = '$v'),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                enough
                    ? 'Kembalian: ${rupiah(paid - total)}'
                    : (paid == 0 ? '' : 'Kurang: ${rupiah(total - paid)}'),
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: enough ? Colors.green.shade700 : Colors.red.shade700),
              ),
            ],
            const SizedBox(height: 12),
            TextField(
              controller: _customer,
              decoration: const InputDecoration(labelText: 'Nama pelanggan (opsional)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _note,
              decoration: const InputDecoration(labelText: 'Catatan (opsional)'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: _busy ? null : () => Navigator.pop(context),
            child: const Text('Batal')),
        FilledButton(
          onPressed: (_busy || !enough || state.cart.isEmpty)
              ? null
              : () => _submit(state, paid),
          child: Text(_busy ? 'Menyimpan...' : 'Bayar'),
        ),
      ],
    );
  }
}
