import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/product.dart';
import '../services/printer_service.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/cart_panel.dart';
import '../widgets/common.dart';
import 'scanner_screen.dart';
import 'settings_screen.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  late final TextEditingController _search;

  @override
  void initState() {
    super.initState();
    _search = TextEditingController(text: context.read<AppState>().query);
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _add(Product p) {
    final err = context.read<AppState>().addToCart(p);
    if (err != null) showMessage(context, err);
  }

  Future<void> _scan() async {
    final state = context.read<AppState>();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ScannerScreen(
          title: 'Scan barang ke keranjang',
          onCode: (code) async {
            final p = await state.db.productByBarcode(code);
            if (p == null) return 'Barcode $code tidak ditemukan';
            final err = state.addToCart(p);
            return err ?? '${p.name} ditambahkan  (${state.cartCount} item)';
          },
        ),
      ),
    );
  }

  Future<void> _openDrawer() async {
    final s = context.read<AppState>().settings;
    final svc = PrinterService.instance;
    final res = await svc.printBytes(await svc.buildDrawer(s), s);
    if (mounted) showMessage(context, res.ok ? 'Laci kas dibuka' : res.message);
  }

  void _openCartSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.8,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (_, __) => const CartPanel(inSheet: true),
      ),
    );
  }

  Widget _catalog(AppState state) {
    return Column(
      children: [
        if (state.settings.name.isEmpty)
          MaterialBanner(
            content: const Text(
                'Lengkapi nama, alamat & logo toko agar tampil di struk.'),
            leading: const Icon(Icons.storefront_outlined),
            actions: [
              TextButton(
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const SettingsScreen())),
                child: const Text('Atur sekarang'),
              ),
            ],
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: TextField(
            controller: _search,
            decoration: InputDecoration(
              hintText: 'Cari nama atau barcode...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                tooltip: 'Scan barcode / QR',
                icon: const Icon(Icons.qr_code_scanner),
                onPressed: _scan,
              ),
            ),
            onChanged: (v) => context.read<AppState>().loadProducts(query: v),
          ),
        ),
        Expanded(
          child: state.products.isEmpty
              ? Center(
                  child: Text(
                    state.query.isEmpty
                        ? 'Belum ada produk.\nTambahkan di tab Produk.'
                        : 'Produk tidak ditemukan',
                    textAlign: TextAlign.center,
                  ),
                )
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 170,
                    childAspectRatio: 0.78,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: state.products.length,
                  itemBuilder: (context, i) {
                    final p = state.products[i];
                    return _ProductTile(product: p, onTap: () => _add(p));
                  },
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final wide = MediaQuery.of(context).size.width >= 760;

    return Scaffold(
      appBar: AppBar(
        title: Text(state.settings.name.isEmpty
            ? 'Rumsho Cash'
            : state.settings.name),
        actions: [
          IconButton(
            tooltip: 'Buka laci kas',
            icon: const Icon(Icons.inbox_outlined),
            onPressed: _openDrawer,
          ),
        ],
      ),
      body: wide
          ? Row(
              children: [
                Expanded(child: _catalog(state)),
                const VerticalDivider(width: 1),
                const SizedBox(width: 380, child: CartPanel()),
              ],
            )
          : _catalog(state),
      bottomNavigationBar: (wide || state.cart.isEmpty)
          ? null
          : Material(
              color: Theme.of(context).colorScheme.primaryContainer,
              child: InkWell(
                onTap: _openCartSheet,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      const Icon(Icons.shopping_cart_outlined),
                      const SizedBox(width: 10),
                      Text('${state.cartCount} item',
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Text(rupiah(state.cartTotal),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(width: 8),
                      const Icon(Icons.keyboard_arrow_up),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  const _ProductTile({required this.product, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = product;
    final theme = Theme.of(context);
    final stockColor = p.isEmpty
        ? Colors.red.shade700
        : (p.isLow ? Colors.orange.shade800 : Colors.grey.shade700);
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) => ProductThumb(
                    path: p.photoPath,
                    size: c.maxWidth < c.maxHeight ? c.maxWidth : c.maxHeight),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(rupiah(p.price),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.bold)),
                  Text('Stok ${p.stock}',
                      style: TextStyle(fontSize: 12, color: stockColor)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
