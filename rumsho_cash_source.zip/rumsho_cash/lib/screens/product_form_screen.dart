import 'dart:io';

import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/product.dart';
import '../services/printer_service.dart';
import '../services/share_service.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'scanner_screen.dart';

/// Tambah / ubah produk: nama, foto, harga, stok, barcode/QR (bisa generate,
/// scan, cetak label & bagikan gambar label).
class ProductFormScreen extends StatefulWidget {
  final Product? product;
  const ProductFormScreen({super.key, this.product});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _form = GlobalKey<FormState>();
  final _labelKey = GlobalKey();
  late final TextEditingController _name;
  late final TextEditingController _barcode;
  late final TextEditingController _price;
  late final TextEditingController _cost;
  late final TextEditingController _stock;
  late final TextEditingController _minStock;
  String? _photoPath;
  bool _qr = false;
  int _copies = 1;
  bool _busy = false;

  bool get _editing => widget.product != null;

  @override
  void initState() {
    super.initState();
    final pr = widget.product;
    _name = TextEditingController(text: pr?.name ?? '');
    _barcode = TextEditingController(text: pr?.barcode ?? '');
    _price = TextEditingController(text: pr == null ? '' : '${pr.price}');
    _cost = TextEditingController(text: pr == null ? '' : '${pr.cost}');
    _stock = TextEditingController(text: '${pr?.stock ?? 0}');
    _minStock = TextEditingController(text: '${pr?.minStock ?? 5}');
    _photoPath = pr?.photoPath;
  }

  @override
  void dispose() {
    for (final c in [_name, _barcode, _price, _cost, _stock, _minStock]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource src) async {
    final x = await ImagePicker()
        .pickImage(source: src, maxWidth: 800, imageQuality: 80);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(dir.path, 'product_photos'))
      ..createSync(recursive: true);
    final ext = p.extension(x.path).isEmpty ? '.jpg' : p.extension(x.path);
    final dest = p.join(
        folder.path, 'p_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(x.path).copy(dest);
    if (mounted) setState(() => _photoPath = dest);
  }

  void _photoSheet() {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Ambil foto'),
            onTap: () {
              Navigator.pop(c);
              _pickPhoto(ImageSource.camera);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Pilih dari galeri'),
            onTap: () {
              Navigator.pop(c);
              _pickPhoto(ImageSource.gallery);
            },
          ),
          if (_photoPath != null)
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Hapus foto'),
              onTap: () {
                Navigator.pop(c);
                setState(() => _photoPath = null);
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _generate() async {
    final code = await context.read<AppState>().db.generateBarcode();
    if (mounted) setState(() => _barcode.text = code);
  }

  Future<void> _scanCode() async {
    final code = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => const ScannerScreen()));
    if (code != null && mounted) setState(() => _barcode.text = code);
  }

  Product _draft() => Product(
        id: widget.product?.id,
        name: _name.text.trim().isEmpty ? 'Nama Produk' : _name.text.trim(),
        barcode: _barcode.text.trim(),
        price: parseRupiah(_price.text),
        cost: parseRupiah(_cost.text),
        stock: int.tryParse(_stock.text.trim()) ?? 0,
        minStock: int.tryParse(_minStock.text.trim()) ?? 5,
        photoPath: _photoPath,
      );

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final state = context.read<AppState>();
    setState(() => _busy = true);
    try {
      if (_barcode.text.trim().isEmpty) {
        _barcode.text = await state.db.generateBarcode();
      }
      final code = _barcode.text.trim();
      final existing = await state.db.productByBarcode(code);
      if (existing != null && existing.id != widget.product?.id) {
        if (mounted) {
          showMessage(context, 'Barcode sudah dipakai oleh "${existing.name}"');
          setState(() => _busy = false);
        }
        return;
      }
      final product = _draft();
      if (_editing) {
        await state.db.updateProduct(product);
        if (product.stock != widget.product!.stock) {
          await state.db.adjustStock(product.id!,
              newStock: product.stock, reason: 'Koreksi dari data barang');
        }
      } else {
        await state.db.insertProduct(product);
      }
      await state.loadProducts();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showMessage(context, 'Gagal menyimpan: $e');
      }
    }
  }

  Future<void> _delete() async {
    final ok = await confirmDialog(context, 'Hapus produk?',
        '"${widget.product!.name}" akan dihapus. Riwayat transaksi lama tetap tersimpan.',
        okLabel: 'Hapus');
    if (!ok || !mounted) return;
    final state = context.read<AppState>();
    await state.db.deleteProduct(widget.product!.id!);
    await state.loadProducts();
    if (mounted) Navigator.pop(context, true);
  }

  Future<void> _printLabel() async {
    if (_barcode.text.trim().isEmpty) {
      showMessage(context, 'Isi atau generate barcode terlebih dahulu.');
      return;
    }
    final s = context.read<AppState>().settings;
    final svc = PrinterService.instance;
    final bytes =
        await svc.buildLabel(_draft(), s, qr: _qr, copies: _copies);
    final res = await svc.printBytes(bytes, s);
    if (mounted) showMessage(context, res.message);
  }

  Future<void> _shareLabel() async {
    final png = await ShareService.capturePng(_labelKey);
    if (png == null) return;
    await ShareService.sharePng(png, 'label_${_barcode.text.trim()}.png');
  }

  Widget _numField(TextEditingController c, String label,
      {String? prefix, bool required = false}) {
    return TextFormField(
      controller: c,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      decoration: InputDecoration(labelText: label, prefixText: prefix),
      onChanged: (_) => setState(() {}),
      validator: required
          ? (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null
          : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final code = _barcode.text.trim();
    final draft = _draft();
    final longCode = !_qr && code.length > 14;

    return Scaffold(
      appBar: AppBar(
        title: Text(_editing ? 'Ubah Produk' : 'Produk Baru'),
        actions: [
          if (_editing)
            IconButton(
                tooltip: 'Hapus',
                icon: const Icon(Icons.delete_outline),
                onPressed: _delete),
        ],
      ),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Center(
              child: GestureDetector(
                onTap: _photoSheet,
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    ProductThumb(path: _photoPath, size: 120),
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: const Icon(Icons.edit, size: 16, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Nama produk'),
              onChanged: (_) => setState(() {}),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _numField(_price, 'Harga jual', prefix: 'Rp ', required: true)),
              const SizedBox(width: 12),
              Expanded(child: _numField(_cost, 'Harga modal', prefix: 'Rp ')),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _numField(_stock, 'Stok')),
              const SizedBox(width: 12),
              Expanded(child: _numField(_minStock, 'Batas stok menipis')),
            ]),
            if (parseRupiah(_price.text) > 0 && parseRupiah(_cost.text) > 0)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  'Untung per item: ${rupiah(parseRupiah(_price.text) - parseRupiah(_cost.text))}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            const SizedBox(height: 20),
            Text('Barcode / QR', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextFormField(
              controller: _barcode,
              decoration: InputDecoration(
                labelText: 'Kode (kosongkan untuk dibuat otomatis)',
                suffixIcon: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                        tooltip: 'Generate kode',
                        icon: const Icon(Icons.autorenew),
                        onPressed: _generate),
                    IconButton(
                        tooltip: 'Scan dari barcode yang sudah ada',
                        icon: const Icon(Icons.qr_code_scanner),
                        onPressed: _scanCode),
                  ],
                ),
              ),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(
                    value: false, label: Text('Barcode'), icon: Icon(Icons.view_week_outlined)),
                ButtonSegment(
                    value: true, label: Text('QR'), icon: Icon(Icons.qr_code_2)),
              ],
              selected: {_qr},
              onSelectionChanged: (s) => setState(() => _qr = s.first),
            ),
            const SizedBox(height: 12),
            if (code.isEmpty)
              const Text('Kode akan dibuat otomatis saat disimpan.')
            else ...[
              Center(
                child: Card(
                  margin: EdgeInsets.zero,
                  clipBehavior: Clip.antiAlias,
                  child: RepaintBoundary(
                    key: _labelKey,
                    child: Container(
                      width: 260,
                      color: Colors.white,
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(draft.name,
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold)),
                          Text(rupiah(draft.price),
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18)),
                          const SizedBox(height: 8),
                          BarcodeWidget(
                            barcode: _qr ? Barcode.qrCode() : Barcode.code128(),
                            data: code,
                            width: _qr ? 150 : 230,
                            height: _qr ? 150 : 70,
                            drawText: !_qr,
                            color: Colors.black,
                            style: const TextStyle(
                                color: Colors.black, fontSize: 12),
                            errorBuilder: (c, e) => Text(
                                'Kode tidak valid untuk barcode: $e',
                                style: const TextStyle(color: Colors.red)),
                          ),
                          if (_qr)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(code,
                                  style: const TextStyle(
                                      color: Colors.black, fontSize: 12)),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              if (longCode)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'Kode cukup panjang: barcode bisa sulit dibaca di kertas 58 mm. Gunakan QR atau kode lebih pendek.',
                    style: TextStyle(color: Colors.orange.shade900, fontSize: 12),
                  ),
                ),
              const SizedBox(height: 12),
              Row(children: [
                const Text('Jumlah label:'),
                IconButton(
                    onPressed: _copies > 1 ? () => setState(() => _copies--) : null,
                    icon: const Icon(Icons.remove_circle_outline)),
                Text('$_copies'),
                IconButton(
                    onPressed: _copies < 50 ? () => setState(() => _copies++) : null,
                    icon: const Icon(Icons.add_circle_outline)),
              ]),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                      onPressed: _printLabel,
                      icon: const Icon(Icons.print_outlined),
                      label: const Text('Cetak label')),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                      onPressed: _shareLabel,
                      icon: const Icon(Icons.share_outlined),
                      label: const Text('Bagikan gambar')),
                ),
              ]),
            ],
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: Text(_busy ? 'Menyimpan...' : 'Simpan'),
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ],
        ),
      ),
    );
  }
}
