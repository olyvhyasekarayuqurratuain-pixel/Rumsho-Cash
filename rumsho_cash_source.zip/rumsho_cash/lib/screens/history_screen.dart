import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'receipt_screen.dart';

/// Riwayat transaksi: lihat ulang, cetak ulang, bagikan, atau batalkan.
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Sale> _sales = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await context.read<AppState>().db.sales(limit: 300);
    if (!mounted) return;
    setState(() {
      _sales = list;
      _loading = false;
    });
  }

  Future<void> _void(Sale s) async {
    final ok = await confirmDialog(
      context,
      'Batalkan transaksi?',
      '${s.invoiceNo} (${rupiah(s.total)}) akan dibatalkan dan stok barang dikembalikan.',
      okLabel: 'Batalkan',
    );
    if (!ok || !mounted) return;
    final state = context.read<AppState>();
    await state.db.voidSale(s.id!);
    await state.loadProducts();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat Transaksi')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _sales.isEmpty
              ? const Center(child: Text('Belum ada transaksi'))
              : ListView.separated(
                  itemCount: _sales.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final s = _sales[i];
                    final strike = s.voided
                        ? const TextStyle(decoration: TextDecoration.lineThrough)
                        : null;
                    return ListTile(
                      title: Text(s.invoiceNo, style: strike),
                      subtitle: Text(
                        '${tanggal(s.createdAt)}  •  ${s.paymentMethod}'
                        '${s.customerName.isEmpty ? '' : '  •  ${s.customerName}'}'
                        '${s.voided ? '  •  BATAL' : ''}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(rupiah(s.total),
                              style: (strike ?? const TextStyle()).copyWith(
                                  fontWeight: FontWeight.bold)),
                          if (!s.voided)
                            PopupMenuButton<String>(
                              onSelected: (v) {
                                if (v == 'void') _void(s);
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(
                                    value: 'void',
                                    child: Text('Batalkan transaksi')),
                              ],
                            ),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ReceiptScreen(sale: s)),
                      ),
                    );
                  },
                ),
    );
  }
}
