import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../models/store_settings.dart';
import '../services/printer_service.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'printer_screen.dart';

/// Identitas toko yang tampil di struk: logo, nama, alamat, catatan kaki.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late StoreSettings _s;
  late final TextEditingController _name;
  late final TextEditingController _address;
  late final TextEditingController _phone;
  late final TextEditingController _footnote;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _s = context.read<AppState>().settings.copy();
    _name = TextEditingController(text: _s.name);
    _address = TextEditingController(text: _s.address);
    _phone = TextEditingController(text: _s.phone);
    _footnote = TextEditingController(text: _s.footnote);
  }

  @override
  void dispose() {
    for (final c in [_name, _address, _phone, _footnote]) {
      c.dispose();
    }
    super.dispose();
  }

  void _collect() {
    _s.name = _name.text.trim();
    _s.address = _address.text.trim();
    _s.phone = _phone.text.trim();
    _s.footnote = _footnote.text.trim();
  }

  Future<void> _pickLogo() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 600, imageQuality: 90);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final ext = p.extension(x.path).isEmpty ? '.png' : p.extension(x.path);
    final dest = p.join(
        dir.path, 'logo_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(x.path).copy(dest);
    if (mounted) setState(() => _s.logoPath = dest);
  }

  Future<void> _save() async {
    _collect();
    setState(() => _busy = true);
    await context.read<AppState>().saveSettings(_s);
    if (!mounted) return;
    setState(() => _busy = false);
    showMessage(context, 'Pengaturan tersimpan');
  }

  Future<void> _testReceipt() async {
    _collect();
    final sample = Sale(
      id: 0,
      invoiceNo: 'INV-CONTOH-0001',
      createdAt: DateTime.now(),
      items: const [
        SaleItem(name: 'Produk Contoh A', barcode: 'RC00000001', qty: 2, price: 15000, cost: 10000),
        SaleItem(name: 'Produk Contoh B', barcode: 'RC00000002', qty: 1, price: 25000, cost: 18000),
      ],
      paid: 60000,
    );
    final svc = PrinterService.instance;
    final res = await svc.printBytes(await svc.buildReceipt(sample, _s), _s);
    if (mounted) showMessage(context, res.message);
  }

  @override
  Widget build(BuildContext context) {
    final hasLogo = _s.logoPath.isNotEmpty && File(_s.logoPath).existsSync();
    return Scaffold(
      appBar: AppBar(title: const Text('Toko & Struk')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: GestureDetector(
              onTap: _pickLogo,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                  image: hasLogo
                      ? DecorationImage(
                          image: FileImage(File(_s.logoPath)),
                          fit: BoxFit.contain)
                      : null,
                ),
                child: hasLogo
                    ? null
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_photo_alternate_outlined, size: 32),
                          SizedBox(height: 4),
                          Text('Logo toko'),
                        ],
                      ),
              ),
            ),
          ),
          if (hasLogo)
            Center(
              child: TextButton(
                  onPressed: () => setState(() => _s.logoPath = ''),
                  child: const Text('Hapus logo')),
            ),
          const SizedBox(height: 12),
          TextField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Nama toko')),
          const SizedBox(height: 12),
          TextField(
              controller: _address,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Alamat toko')),
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'No. telepon / WhatsApp')),
          const SizedBox(height: 12),
          TextField(
            controller: _footnote,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'Catatan kaki struk',
              hintText: 'IG @tokosaya  |  Promo: beli 3 gratis 1',
              helperText: 'Tampil di bagian bawah struk (info medsos / promo)',
            ),
          ),
          const SizedBox(height: 20),
          Text('Kertas printer', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 58, label: Text('58 mm')),
              ButtonSegment(value: 80, label: Text('80 mm')),
            ],
            selected: {_s.paperMm},
            onSelectionChanged: (v) => setState(() => _s.paperMm = v.first),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Cetak struk otomatis setelah bayar'),
            value: _s.autoPrint,
            onChanged: (v) => setState(() => _s.autoPrint = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Buka cash drawer saat bayar tunai'),
            subtitle: const Text('Laci tersambung ke port RJ11 printer'),
            value: _s.openDrawer,
            onChanged: (v) => setState(() => _s.openDrawer = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Izinkan jual saat stok habis'),
            subtitle: const Text('Stok bisa menjadi minus'),
            value: _s.allowOversell,
            onChanged: (v) => setState(() => _s.allowOversell = v),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PrinterScreen())),
            icon: const Icon(Icons.bluetooth),
            label: Text(_s.printerName.isEmpty
                ? 'Pilih printer Bluetooth'
                : 'Printer: ${_s.printerName}'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _testReceipt,
            icon: const Icon(Icons.receipt_long_outlined),
            label: const Text('Cetak struk contoh'),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('Simpan'),
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14)),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
