import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

/// Membaca BARCODE / QR lewat kamera (offline).
///
/// - Tanpa [onCode]: layar menutup dan mengembalikan kode pertama yang terbaca.
/// - Dengan [onCode]: mode terus-menerus (dipakai di kasir). Callback
///   mengembalikan teks status yang ditampilkan di bawah kamera.
class ScannerScreen extends StatefulWidget {
  final String title;
  final Future<String?> Function(String code)? onCode;
  const ScannerScreen({super.key, this.title = 'Scan Barcode / QR', this.onCode});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final MobileScannerController _controller =
      MobileScannerController(facing: CameraFacing.back, torchEnabled: false);
  bool _torch = false;
  bool _handling = false;
  String _lastCode = '';
  DateTime _lastAt = DateTime.fromMillisecondsSinceEpoch(0);
  String _status = 'Arahkan kamera ke barcode / QR';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_handling) return;
    String? code;
    for (final b in capture.barcodes) {
      final v = b.rawValue;
      if (v != null && v.isNotEmpty) {
        code = v;
        break;
      }
    }
    if (code == null) return;

    final now = DateTime.now();
    if (code == _lastCode &&
        now.difference(_lastAt) < const Duration(milliseconds: 1500)) {
      return;
    }
    _lastCode = code;
    _lastAt = now;
    HapticFeedback.mediumImpact();

    _handling = true;
    if (widget.onCode == null) {
      if (mounted) Navigator.pop(context, code);
      return;
    }
    final msg = await widget.onCode!(code);
    _handling = false;
    if (mounted) setState(() => _status = msg ?? code!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            tooltip: 'Lampu senter',
            icon: Icon(_torch ? Icons.flash_on : Icons.flash_off),
            onPressed: () async {
              await _controller.toggleTorch();
              setState(() => _torch = !_torch);
            },
          ),
          IconButton(
            tooltip: 'Ganti kamera',
            icon: const Icon(Icons.cameraswitch_outlined),
            onPressed: () => _controller.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            errorBuilder: (context, error, child) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Kamera tidak bisa dibuka.\nPastikan izin kamera diberikan.\n(${error.errorCode.name})',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
          Center(
            child: Container(
              width: 260,
              height: 180,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white70, width: 2),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              color: Colors.black54,
              padding: const EdgeInsets.all(16),
              child: SafeArea(
                top: false,
                child: Text(_status,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
