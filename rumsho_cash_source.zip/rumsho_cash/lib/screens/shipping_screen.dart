import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../models/shipment.dart';
import '../services/printer_service.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

/// Daftar resi pengiriman (untuk pebisnis online).
class ShippingScreen extends StatefulWidget {
  const ShippingScreen({super.key});

  @override
  State<ShippingScreen> createState() => _ShippingScreenState();
}

class _ShippingScreenState extends State<ShippingScreen> {
  List<Shipment> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await context.read<AppState>().db.shipments();
    if (!mounted) return;
    setState(() {
      _items = list;
      _loading = false;
    });
  }

  Future<void> _open([Shipment? s]) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => ShipmentFormScreen(shipment: s)));
    _load();
  }

  Future<void> _print(Shipment s) async {
    final settings = context.read<AppState>().settings;
    final svc = PrinterService.instance;
    final res =
        await svc.printBytes(await svc.buildShipment(s, settings), settings);
    if (mounted) showMessage(context, res.message);
  }

  Future<void> _delete(Shipment s) async {
    final ok = await confirmDialog(context, 'Hapus resi?',
        'Resi untuk ${s.receiverName} akan dihapus.',
        okLabel: 'Hapus');
    if (!ok || !mounted) return;
    await context.read<AppState>().db.deleteShipment(s.id!);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Resi Pengiriman')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(),
        icon: const Icon(Icons.add),
        label: const Text('Resi baru'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(
                  child: Text('Belum ada resi.\nKetuk "Resi baru" untuk membuat.',
                      textAlign: TextAlign.center))
              : ListView.separated(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final s = _items[i];
                    return ListTile(
                      leading: const CircleAvatar(
                          child: Icon(Icons.local_shipping_outlined)),
                      title: Text(s.receiverName,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                        '${s.courier.isEmpty ? '-' : s.courier}'
                        '${s.trackingNo.isEmpty ? '' : '  •  ${s.trackingNo}'}'
                        '${s.codAmount > 0 ? '  •  COD ${rupiah(s.codAmount)}' : ''}\n'
                        '${tanggal(s.createdAt)}',
                      ),
                      isThreeLine: true,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'Cetak resi',
                            icon: const Icon(Icons.print_outlined),
                            onPressed: () => _print(s),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'delete') _delete(s);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'delete', child: Text('Hapus')),
                            ],
                          ),
                        ],
                      ),
                      onTap: () => _open(s),
                    );
                  },
                ),
    );
  }
}

/// Form resi. Bisa diisi otomatis dari transaksi ([fromSale]).
class ShipmentFormScreen extends StatefulWidget {
  final Shipment? shipment;
  final Sale? fromSale;
  const ShipmentFormScreen({super.key, this.shipment, this.fromSale});

  @override
  State<ShipmentFormScreen> createState() => _ShipmentFormScreenState();
}

class _ShipmentFormScreenState extends State<ShipmentFormScreen> {
  static const _couriers = [
    'JNE',
    'J&T',
    'SiCepat',
    'AnterAja',
    'Ninja',
    'Pos Indonesia',
    'GoSend',
    'Grab',
    'Ambil sendiri',
  ];

  final _form = GlobalKey<FormState>();
  late final TextEditingController _rName;
  late final TextEditingController _rPhone;
  late final TextEditingController _rAddress;
  late final TextEditingController _sName;
  late final TextEditingController _sPhone;
  late final TextEditingController _sAddress;
  late final TextEditingController _courier;
  late final TextEditingController _tracking;
  late final TextEditingController _item;
  late final TextEditingController _weight;
  late final TextEditingController _cod;
  late final TextEditingController _note;
  bool _busy = false;

  bool get _editing => widget.shipment != null;

  @override
  void initState() {
    super.initState();
    final s = widget.shipment;
    final store = context.read<AppState>().settings;
    final sale = widget.fromSale;
    final desc = sale == null
        ? ''
        : sale.items.map((e) => '${e.name} x${e.qty}').join(', ');

    _rName = TextEditingController(text: s?.receiverName ?? sale?.customerName ?? '');
    _rPhone = TextEditingController(text: s?.receiverPhone ?? '');
    _rAddress = TextEditingController(text: s?.receiverAddress ?? '');
    _sName = TextEditingController(text: s?.senderName ?? store.name);
    _sPhone = TextEditingController(text: s?.senderPhone ?? store.phone);
    _sAddress = TextEditingController(text: s?.senderAddress ?? store.address);
    _courier = TextEditingController(text: s?.courier ?? '');
    _tracking = TextEditingController(text: s?.trackingNo ?? '');
    _item = TextEditingController(text: s?.itemDesc ?? desc);
    _weight = TextEditingController(
        text: (s?.weightGram ?? 0) > 0 ? '${s!.weightGram}' : '');
    _cod = TextEditingController(
        text: (s?.codAmount ?? 0) > 0 ? '${s!.codAmount}' : '');
    _note = TextEditingController(text: s?.note ?? '');
  }

  @override
  void dispose() {
    for (final c in [
      _rName, _rPhone, _rAddress, _sName, _sPhone, _sAddress,
      _courier, _tracking, _item, _weight, _cod, _note,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Shipment _build() => Shipment(
        id: widget.shipment?.id,
        createdAt: widget.shipment?.createdAt ?? DateTime.now(),
        senderName: _sName.text.trim(),
        senderPhone: _sPhone.text.trim(),
        senderAddress: _sAddress.text.trim(),
        receiverName: _rName.text.trim(),
        receiverPhone: _rPhone.text.trim(),
        receiverAddress: _rAddress.text.trim(),
        courier: _courier.text.trim(),
        trackingNo: _tracking.text.trim(),
        itemDesc: _item.text.trim(),
        weightGram: parseRupiah(_weight.text),
        codAmount: parseRupiah(_cod.text),
        note: _note.text.trim(),
      );

  Future<void> _save({required bool print}) async {
    if (!_form.currentState!.validate()) return;
    final state = context.read<AppState>();
    setState(() => _busy = true);
    try {
      var sh = _build();
      if (_editing) {
        await state.db.updateShipment(sh);
      } else {
        final id = await state.db.insertShipment(sh);
        sh = sh.copyWith(id: id);
      }
      if (print) {
        final svc = PrinterService.instance;
        final res = await svc.printBytes(
            await svc.buildShipment(sh, state.settings), state.settings);
        if (mounted) showMessage(context, res.message);
        if (!res.ok) {
          // Data sudah tersimpan; tetap di layar agar bisa dicoba cetak ulang.
          if (mounted) setState(() => _busy = false);
          return;
        }
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showMessage(context, 'Gagal menyimpan: $e');
      }
    }
  }

  String? _req(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null;

  @override
  Widget build(BuildContext context) {
    final h = Theme.of(context).textTheme.titleMedium;
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Ubah Resi' : 'Resi Baru')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Penerima', style: h),
            const SizedBox(height: 8),
            TextFormField(
                controller: _rName,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Nama penerima'),
                validator: _req),
            const SizedBox(height: 10),
            TextFormField(
                controller: _rPhone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'No. telepon / WhatsApp')),
            const SizedBox(height: 10),
            TextFormField(
                controller: _rAddress,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'Alamat lengkap'),
                validator: _req),
            const SizedBox(height: 20),
            Text('Kurir & paket', style: h),
            const SizedBox(height: 8),
            TextFormField(
                controller: _courier,
                decoration: const InputDecoration(labelText: 'Kurir / ekspedisi')),
            Wrap(
              spacing: 6,
              children: [
                for (final c in _couriers)
                  ActionChip(
                      label: Text(c),
                      onPressed: () => setState(() => _courier.text = c)),
              ],
            ),
            const SizedBox(height: 10),
            TextFormField(
                controller: _tracking,
                decoration: const InputDecoration(
                    labelText: 'Nomor resi kurir (opsional)',
                    helperText: 'Jika diisi, dicetak sebagai barcode')),
            const SizedBox(height: 10),
            TextFormField(
                controller: _item,
                minLines: 1,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Isi paket')),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: _weight,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(labelText: 'Berat', suffixText: 'gram'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _cod,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                      labelText: 'Nominal COD', prefixText: 'Rp '),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            TextFormField(
                controller: _note,
                decoration: const InputDecoration(labelText: 'Catatan (cth: Fragile)')),
            const SizedBox(height: 20),
            Text('Pengirim', style: h),
            const SizedBox(height: 8),
            TextFormField(
                controller: _sName,
                decoration: const InputDecoration(labelText: 'Nama pengirim / toko')),
            const SizedBox(height: 10),
            TextFormField(
                controller: _sPhone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'No. telepon pengirim')),
            const SizedBox(height: 10),
            TextFormField(
                controller: _sAddress,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'Alamat pengirim')),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _busy ? null : () => _save(print: false),
                  style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: const Text('Simpan'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _busy ? null : () => _save(print: true),
                  icon: const Icon(Icons.print_outlined),
                  label: const Text('Simpan & Cetak'),
                  style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                ),
              ),
            ]),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
