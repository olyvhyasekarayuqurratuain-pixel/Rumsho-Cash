import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../services/printer_service.dart';
import '../services/share_service.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/receipt_view.dart';
import 'shipping_screen.dart';

/// Struk digital + cetak struk kertas (thermal Bluetooth) + bagikan ke pelanggan.
class ReceiptScreen extends StatefulWidget {
  final Sale sale;
  final bool justPaid;
  const ReceiptScreen({super.key, required this.sale, this.justPaid = false});

  @override
  State<ReceiptScreen> createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  final _boundaryKey = GlobalKey();
  bool _printing = false;
  late bool _drawerPending;

  @override
  void initState() {
    super.initState();
    _drawerPending = widget.justPaid;
    if (widget.justPaid) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && context.read<AppState>().settings.autoPrint) _print();
      });
    }
  }

  Future<void> _print() async {
    final s = context.read<AppState>().settings;
    final svc = PrinterService.instance;
    setState(() => _printing = true);
    final openDrawer =
        _drawerPending && s.openDrawer && widget.sale.paymentMethod == 'Tunai';
    final bytes =
        await svc.buildReceipt(widget.sale, s, openDrawer: openDrawer);
    final res = await svc.printBytes(bytes, s);
    if (!mounted) return;
    if (res.ok) _drawerPending = false;
    setState(() => _printing = false);
    showMessage(context, res.message);
  }

  Future<void> _share() async {
    final s = context.read<AppState>().settings;
    final png = await ShareService.capturePng(_boundaryKey);
    if (png == null) {
      if (mounted) showMessage(context, 'Gagal membuat gambar struk.');
      return;
    }
    final shop = s.name.isEmpty ? 'kami' : s.name;
    await ShareService.sharePng(
      png,
      '${widget.sale.invoiceNo}.png',
      subject: 'Struk ${widget.sale.invoiceNo} - $shop',
      text:
          'Terima kasih sudah berbelanja di $shop. Berikut struk digital Anda (${widget.sale.invoiceNo}).',
    );
  }

  Future<void> _openDrawer() async {
    final s = context.read<AppState>().settings;
    final svc = PrinterService.instance;
    final res = await svc.printBytes(await svc.buildDrawer(s), s);
    if (mounted) showMessage(context, res.ok ? 'Laci kas dibuka' : res.message);
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppState>().settings;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.sale.invoiceNo),
        actions: [
          IconButton(
            tooltip: 'Buat resi pengiriman',
            icon: const Icon(Icons.local_shipping_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => ShipmentFormScreen(fromSale: widget.sale)),
            ),
          ),
          IconButton(
            tooltip: 'Buka laci kas',
            icon: const Icon(Icons.inbox_outlined),
            onPressed: _openDrawer,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Card(
            margin: EdgeInsets.zero,
            clipBehavior: Clip.antiAlias,
            child: RepaintBoundary(
              key: _boundaryKey,
              child: ReceiptView(sale: widget.sale, settings: settings),
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _printing ? null : _print,
                  icon: _printing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.print_outlined),
                  label: const Text('Cetak'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _share,
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('Bagikan'),
                ),
              ),
              if (widget.justPaid) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.add_shopping_cart),
                    label: const Text('Baru'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
