import 'package:flutter/material.dart';

import 'history_screen.dart';
import 'printer_screen.dart';
import 'settings_screen.dart';
import 'shipping_screen.dart';
import 'stock_screen.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  void _go(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Menu')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.history),
            title: const Text('Riwayat Transaksi'),
            subtitle: const Text('Lihat ulang, cetak ulang, bagikan struk'),
            onTap: () => _go(context, const HistoryScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.inventory_outlined),
            title: const Text('Stok Barang'),
            subtitle: const Text('Restock, stok opname, riwayat stok'),
            onTap: () => _go(context, const StockScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.local_shipping_outlined),
            title: const Text('Resi Pengiriman'),
            subtitle: const Text('Cetak resi untuk paket online'),
            onTap: () => _go(context, const ShippingScreen()),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.storefront_outlined),
            title: const Text('Toko & Struk'),
            subtitle: const Text('Logo, nama, alamat, catatan kaki'),
            onTap: () => _go(context, const SettingsScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.bluetooth),
            title: const Text('Printer Bluetooth'),
            subtitle: const Text('Hubungkan printer thermal & cash drawer'),
            onTap: () => _go(context, const PrinterScreen()),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('Rumsho Cash 1.0.0'),
            subtitle: Text(
                'Kasir offline. Data tersimpan di perangkat ini. Tanpa iklan, tanpa langganan.'),
          ),
        ],
      ),
    );
  }
}
