import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../db/app_database.dart';
import '../models/product.dart';
import '../services/export_service.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'scanner_screen.dart';

/// Catat jumlah stok persediaan: restock, kurangi, atau stok opname.
class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  final _search = TextEditingController();
  List<Product> _all = [];
  bool _loading = true;
  int _filter = 0; // 0 semua, 1 menipis, 2 habis

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final list =
        await context.read<AppState>().db.products(query: _search.text);
    if (!mounted) return;
    setState(() {
      _all = list;
      _loading = false;
    });
  }

  List<Product> get _shown => _all.where((p) {
        if (_filter == 1) return p.isLow;
        if (_filter == 2) return p.isEmpty;
        return true;
      }).toList();

  Future<void> _scan() async {
    final code = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => const ScannerScreen()));
    if (code == null) return;
    _search.text = code;
    _load();
  }

  Future<void> _adjust(Product p) async {
    final state = context.read<AppState>();
    final amount = TextEditingController();
    final reason = TextEditingController();
    var mode = 0; // 0 tambah, 1 kurangi, 2 set

    final result = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final n = int.tryParse(amount.text.trim());
          final next = n == null
              ? null
              : (mode == 0
                  ? p.stock + n
                  : mode == 1
                      ? (p.stock - n < 0 ? 0 : p.stock - n)
                      : n);
          return AlertDialog(
            title: Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Stok saat ini: ${p.stock}'),
                  const SizedBox(height: 12),
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, label: Text('Tambah')),
                      ButtonSegment(value: 1, label: Text('Kurangi')),
                      ButtonSegment(value: 2, label: Text('Set')),
                    ],
                    selected: {mode},
                    onSelectionChanged: (s) => setD(() => mode = s.first),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: amount,
                    autofocus: true,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                        labelText: mode == 2 ? 'Stok sebenarnya' : 'Jumlah'),
                    onChanged: (_) => setD(() {}),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: reason,
                    decoration: const InputDecoration(
                        labelText: 'Keterangan (opsional)',
                        hintText: 'cth: restock supplier'),
                  ),
                  if (next != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text('Stok menjadi: $next',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(c, false),
                  child: const Text('Batal')),
              FilledButton(
                  onPressed: next == null ? null : () => Navigator.pop(c, true),
                  child: const Text('Simpan')),
            ],
          );
        },
      ),
    );

    if (result != true) return;
    final n = int.tryParse(amount.text.trim());
    if (n == null) return;
    final newStock = mode == 0
        ? p.stock + n
        : mode == 1
            ? (p.stock - n < 0 ? 0 : p.stock - n)
            : n;
    final label = mode == 0 ? 'Restock' : (mode == 1 ? 'Pengurangan' : 'Stok opname');
    final note = reason.text.trim();
    await state.db.adjustStock(p.id!,
        newStock: newStock, reason: note.isEmpty ? label : '$label: $note');
    await state.loadProducts();
    _load();
  }

  Future<void> _history(Product p) async {
    final moves = await context.read<AppState>().db.stockMoves(p.id!);
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _MovesSheet(product: p, moves: moves),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shown = _shown;
    final units = _all.fold<int>(0, (a, p) => a + p.stock);
    final costValue = _all.fold<int>(0, (a, p) => a + p.stock * p.cost);
    final saleValue = _all.fold<int>(0, (a, p) => a + p.stock * p.price);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Stok Barang'),
        actions: [
          IconButton(
            tooltip: 'Export Excel',
            icon: const Icon(Icons.table_view_outlined),
            onPressed: _all.isEmpty
                ? null
                : () async {
                    final s = context.read<AppState>().settings;
                    try {
                      await ExportService.exportStock(_all, s);
                    } catch (e) {
                      if (mounted) showMessage(context, 'Gagal export: $e');
                    }
                  },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                  child: Row(children: [
                    Expanded(
                        child: StatCard(
                            label: 'Total unit',
                            value: '$units',
                            icon: Icons.inventory_2_outlined)),
                    const SizedBox(width: 8),
                    Expanded(
                        child: StatCard(
                            label: 'Nilai modal',
                            value: rupiah(costValue),
                            icon: Icons.savings_outlined)),
                    const SizedBox(width: 8),
                    Expanded(
                        child: StatCard(
                            label: 'Nilai jual',
                            value: rupiah(saleValue),
                            icon: Icons.sell_outlined)),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: TextField(
                    controller: _search,
                    decoration: InputDecoration(
                      hintText: 'Cari nama atau barcode...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: IconButton(
                          tooltip: 'Scan barcode / QR',
                          icon: const Icon(Icons.qr_code_scanner),
                          onPressed: _scan),
                    ),
                    onChanged: (_) => _load(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Wrap(spacing: 8, children: [
                    ChoiceChip(
                        label: const Text('Semua'),
                        selected: _filter == 0,
                        onSelected: (_) => setState(() => _filter = 0)),
                    ChoiceChip(
                        label: const Text('Menipis'),
                        selected: _filter == 1,
                        onSelected: (_) => setState(() => _filter = 1)),
                    ChoiceChip(
                        label: const Text('Habis'),
                        selected: _filter == 2,
                        onSelected: (_) => setState(() => _filter = 2)),
                  ]),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const Center(child: Text('Tidak ada barang'))
                      : ListView.separated(
                          itemCount: shown.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final p = shown[i];
                            final color = p.isEmpty
                                ? Colors.red.shade700
                                : (p.isLow
                                    ? Colors.orange.shade800
                                    : Colors.green.shade800);
                            return ListTile(
                              leading: ProductThumb(path: p.photoPath, size: 44),
                              title: Text(p.name,
                                  maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text(p.barcode),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('${p.stock}',
                                      style: TextStyle(
                                          color: color,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18)),
                                  IconButton(
                                    tooltip: 'Riwayat stok',
                                    icon: const Icon(Icons.history),
                                    onPressed: () => _history(p),
                                  ),
                                ],
                              ),
                              onTap: () => _adjust(p),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _MovesSheet extends StatelessWidget {
  final Product product;
  final List<StockMove> moves;
  const _MovesSheet({required this.product, required this.moves});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          title: Text(product.name,
              style: Theme.of(context).textTheme.titleMedium),
          subtitle: const Text('Riwayat perubahan stok'),
        ),
        const Divider(height: 1),
        Expanded(
          child: moves.isEmpty
              ? const Center(child: Text('Belum ada riwayat'))
              : ListView.separated(
                  itemCount: moves.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final m = moves[i];
                    final plus = m.delta > 0;
                    return ListTile(
                      dense: true,
                      title: Text(m.reason),
                      subtitle: Text(tanggal(m.createdAt)),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('${plus ? '+' : ''}${m.delta}',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: plus
                                      ? Colors.green.shade700
                                      : Colors.red.shade700)),
                          Text('sisa ${m.stockAfter}',
                              style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
