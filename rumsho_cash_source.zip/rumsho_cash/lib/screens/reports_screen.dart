import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/sale.dart';
import '../services/export_service.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

class _Day {
  int revenue = 0;
  int profit = 0;
  int count = 0;
}

class _Top {
  final String name;
  int qty = 0;
  int revenue = 0;
  int profit = 0;
  _Top(this.name);
}

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String _period = 'today'; // today | week | month | custom
  DateTimeRange? _custom;
  List<Sale> _sales = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  /// (awal inklusif, akhir eksklusif)
  (DateTime, DateTime) _range() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    switch (_period) {
      case 'week':
        return (today.subtract(const Duration(days: 6)),
            today.add(const Duration(days: 1)));
      case 'month':
        return (DateTime(now.year, now.month, 1),
            DateTime(now.year, now.month + 1, 1));
      case 'custom':
        final r = _custom ?? DateTimeRange(start: today, end: today);
        return (
          DateTime(r.start.year, r.start.month, r.start.day),
          DateTime(r.end.year, r.end.month, r.end.day)
              .add(const Duration(days: 1)),
        );
      default:
        return (today, today.add(const Duration(days: 1)));
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final (from, to) = _range();
    final list = await context
        .read<AppState>()
        .db
        .sales(from: from, to: to, includeVoided: false);
    if (!mounted) return;
    setState(() {
      _sales = list;
      _loading = false;
    });
  }

  Future<void> _pickCustom() async {
    final now = DateTime.now();
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: now.add(const Duration(days: 1)),
      initialDateRange: _custom,
    );
    if (r == null) return;
    setState(() {
      _custom = r;
      _period = 'custom';
    });
    _load();
  }

  Future<void> _export() async {
    final (from, to) = _range();
    try {
      await ExportService.exportSales(
        sales: _sales,
        from: from,
        toInclusive: to.subtract(const Duration(days: 1)),
        settings: context.read<AppState>().settings,
      );
    } catch (e) {
      if (mounted) showMessage(context, 'Gagal export: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final revenue = _sales.fold<int>(0, (a, s) => a + s.total);
    final profit = _sales.fold<int>(0, (a, s) => a + s.profit);
    final items = _sales.fold<int>(0, (a, s) => a + s.itemCount);

    final perDay = <String, _Day>{};
    final top = <String, _Top>{};
    final byMethod = <String, _Day>{};
    for (final s in _sales) {
      final key = DateFormat('yyyy-MM-dd').format(s.createdAt);
      final d = perDay.putIfAbsent(key, _Day.new);
      d.revenue += s.total;
      d.profit += s.profit;
      d.count += 1;
      final m = byMethod.putIfAbsent(s.paymentMethod, _Day.new);
      m.revenue += s.total;
      m.count += 1;
      for (final it in s.items) {
        final t = top.putIfAbsent('${it.barcode}|${it.name}', () => _Top(it.name));
        t.qty += it.qty;
        t.revenue += it.subtotal;
        t.profit += it.profit;
      }
    }
    final days = perDay.entries.toList()..sort((a, b) => b.key.compareTo(a.key));
    final maxDay = days.fold<int>(1, (a, e) => e.value.revenue > a ? e.value.revenue : a);
    final topList = top.values.toList()..sort((a, b) => b.qty.compareTo(a.qty));

    final (from, to) = _range();
    final last = to.subtract(const Duration(days: 1));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Laporan'),
        actions: [
          IconButton(
            tooltip: 'Export Excel',
            icon: const Icon(Icons.table_view_outlined),
            onPressed: _sales.isEmpty ? null : _export,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Wrap(spacing: 8, children: [
              ChoiceChip(
                  label: const Text('Hari ini'),
                  selected: _period == 'today',
                  onSelected: (_) {
                    setState(() => _period = 'today');
                    _load();
                  }),
              ChoiceChip(
                  label: const Text('7 hari'),
                  selected: _period == 'week',
                  onSelected: (_) {
                    setState(() => _period = 'week');
                    _load();
                  }),
              ChoiceChip(
                  label: const Text('Bulan ini'),
                  selected: _period == 'month',
                  onSelected: (_) {
                    setState(() => _period = 'month');
                    _load();
                  }),
              ChoiceChip(
                  avatar: const Icon(Icons.date_range, size: 18),
                  label: const Text('Pilih tanggal'),
                  selected: _period == 'custom',
                  onSelected: (_) => _pickCustom()),
            ]),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                from == DateTime(last.year, last.month, last.day)
                    ? tanggalHari(from)
                    : '${tanggalHari(from)}  –  ${tanggalHari(last)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
            if (_loading)
              const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: CircularProgressIndicator()))
            else ...[
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 2.2,
                children: [
                  StatCard(
                      label: 'Omzet',
                      value: rupiah(revenue),
                      icon: Icons.payments_outlined),
                  StatCard(
                      label: 'Profit / Keuntungan',
                      value: rupiah(profit),
                      icon: Icons.trending_up,
                      color: Colors.green.shade700),
                  StatCard(
                      label: 'Transaksi',
                      value: '${_sales.length}',
                      icon: Icons.receipt_long_outlined),
                  StatCard(
                      label: 'Item terjual',
                      value: '$items',
                      icon: Icons.shopping_bag_outlined),
                ],
              ),
              const SizedBox(height: 16),
              if (_sales.isEmpty)
                const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: Text('Belum ada transaksi pada periode ini')))
              else ...[
                _section('Penjualan per hari'),
                Card(
                  margin: EdgeInsets.zero,
                  child: Column(children: [
                    for (final e in days)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(tanggalHari(DateTime.parse(e.key))),
                                Text(rupiah(e.value.revenue),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold)),
                              ],
                            ),
                            const SizedBox(height: 4),
                            LinearProgressIndicator(
                                value: e.value.revenue / maxDay,
                                minHeight: 6,
                                borderRadius: BorderRadius.circular(3)),
                            const SizedBox(height: 4),
                            Text(
                                '${e.value.count} transaksi  •  profit ${rupiah(e.value.profit)}',
                                style: Theme.of(context).textTheme.bodySmall),
                          ],
                        ),
                      ),
                  ]),
                ),
                const SizedBox(height: 16),
                _section('Produk terlaris'),
                Card(
                  margin: EdgeInsets.zero,
                  child: Column(children: [
                    for (var i = 0; i < topList.length && i < 10; i++)
                      ListTile(
                        dense: true,
                        leading: CircleAvatar(
                            radius: 14, child: Text('${i + 1}', style: const TextStyle(fontSize: 12))),
                        title: Text(topList[i].name,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                            'Omzet ${rupiah(topList[i].revenue)}  •  profit ${rupiah(topList[i].profit)}'),
                        trailing: Text('${topList[i].qty} pcs',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                  ]),
                ),
                const SizedBox(height: 16),
                _section('Metode pembayaran'),
                Card(
                  margin: EdgeInsets.zero,
                  child: Column(children: [
                    for (final e in byMethod.entries)
                      ListTile(
                        dense: true,
                        title: Text(e.key),
                        subtitle: Text('${e.value.count} transaksi'),
                        trailing: Text(rupiah(e.value.revenue),
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                  ]),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _export,
                  icon: const Icon(Icons.table_view_outlined),
                  label: const Text('Export ke Excel (.xlsx)'),
                  style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                ),
                const SizedBox(height: 24),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t, style: Theme.of(context).textTheme.titleMedium),
      );
}
