import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:provider/provider.dart';

import '../services/printer_service.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

/// Pilih & hubungkan printer thermal Bluetooth yang sudah di-pairing di
/// pengaturan Bluetooth Android. Printer tidak butuh internet.
class PrinterScreen extends StatefulWidget {
  const PrinterScreen({super.key});

  @override
  State<PrinterScreen> createState() => _PrinterScreenState();
}

class _PrinterScreenState extends State<PrinterScreen> {
  final _svc = PrinterService.instance;
  List<BluetoothInfo> _devices = [];
  bool _loading = true;
  bool _connected = false;
  String? _busyMac;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final ok = await _svc.ensurePermissions();
    var devices = <BluetoothInfo>[];
    var connected = false;
    if (ok) {
      devices = await _svc.pairedDevices();
      connected = await _svc.isConnected();
    }
    if (!mounted) return;
    setState(() {
      _devices = devices;
      _connected = connected;
      _loading = false;
    });
    if (!ok) showMessage(context, 'Izin Bluetooth belum diberikan.');
  }

  Future<void> _choose(BluetoothInfo d) async {
    final state = context.read<AppState>();
    setState(() => _busyMac = d.macAdress);
    final ok = await _svc.connect(d.macAdress);
    if (!mounted) return;
    setState(() => _busyMac = null);
    if (ok) {
      final s = state.settings.copy()
        ..printerMac = d.macAdress
        ..printerName = d.name;
      await state.saveSettings(s);
      if (!mounted) return;
      setState(() => _connected = true);
      showMessage(context, 'Terhubung ke ${d.name}');
    } else {
      showMessage(context,
          'Gagal terhubung. Pastikan printer menyala, dekat, dan sudah di-pairing.');
    }
  }

  Future<void> _test() async {
    final s = context.read<AppState>().settings;
    final res = await _svc.printBytes(await _svc.buildTest(s), s);
    if (mounted) showMessage(context, res.message);
  }

  Future<void> _drawer() async {
    final s = context.read<AppState>().settings;
    final res = await _svc.printBytes(await _svc.buildDrawer(s), s);
    if (mounted) showMessage(context, res.ok ? 'Perintah buka laci kas terkirim' : res.message);
  }

  Future<void> _disconnect() async {
    await _svc.disconnect();
    if (mounted) setState(() => _connected = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>().settings;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Printer Bluetooth'),
        actions: [
          IconButton(
              tooltip: 'Muat ulang',
              icon: const Icon(Icons.refresh),
              onPressed: _refresh),
        ],
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(_connected ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
                color: _connected ? Colors.green.shade700 : null),
            title: Text(s.printerName.isEmpty ? 'Belum ada printer dipilih' : s.printerName),
            subtitle: Text(_connected ? 'Terhubung' : (s.printerMac.isEmpty ? '-' : 'Belum terhubung')),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(
                  onPressed: _test,
                  icon: const Icon(Icons.print_outlined),
                  label: const Text('Tes cetak')),
              OutlinedButton.icon(
                  onPressed: _drawer,
                  icon: const Icon(Icons.inbox_outlined),
                  label: const Text('Tes buka laci kas')),
              if (_connected)
                TextButton(onPressed: _disconnect, child: const Text('Putuskan')),
            ]),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: Text('Printer yang sudah di-pairing',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          if (_loading)
            const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()))
          else if (_devices.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                  'Tidak ada perangkat. Nyalakan printer, lalu pairing dulu di '
                  'Pengaturan Android > Bluetooth (PIN umumnya 0000 atau 1234). '
                  'Setelah itu ketuk tombol muat ulang di atas.'),
            )
          else
            for (final d in _devices)
              ListTile(
                leading: const Icon(Icons.print_outlined),
                title: Text(d.name),
                subtitle: Text(d.macAdress),
                trailing: _busyMac == d.macAdress
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : (s.printerMac == d.macAdress
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : null),
                onTap: _busyMac == null ? () => _choose(d) : null,
              ),
        ],
      ),
    );
  }
}
