class Shipment {
  final int? id;
  final DateTime createdAt;
  final String senderName;
  final String senderPhone;
  final String senderAddress;
  final String receiverName;
  final String receiverPhone;
  final String receiverAddress;
  final String courier;
  final String trackingNo;
  final String itemDesc;
  final int weightGram;
  final int codAmount; // 0 = bukan COD
  final String note;

  const Shipment({
    this.id,
    required this.createdAt,
    this.senderName = '',
    this.senderPhone = '',
    this.senderAddress = '',
    required this.receiverName,
    this.receiverPhone = '',
    required this.receiverAddress,
    this.courier = '',
    this.trackingNo = '',
    this.itemDesc = '',
    this.weightGram = 0,
    this.codAmount = 0,
    this.note = '',
  });

  Shipment copyWith({int? id}) => Shipment(
        id: id ?? this.id,
        createdAt: createdAt,
        senderName: senderName,
        senderPhone: senderPhone,
        senderAddress: senderAddress,
        receiverName: receiverName,
        receiverPhone: receiverPhone,
        receiverAddress: receiverAddress,
        courier: courier,
        trackingNo: trackingNo,
        itemDesc: itemDesc,
        weightGram: weightGram,
        codAmount: codAmount,
        note: note,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'created_at': createdAt.toIso8601String(),
        'sender_name': senderName,
        'sender_phone': senderPhone,
        'sender_address': senderAddress,
        'receiver_name': receiverName,
        'receiver_phone': receiverPhone,
        'receiver_address': receiverAddress,
        'courier': courier,
        'tracking_no': trackingNo,
        'item_desc': itemDesc,
        'weight_gram': weightGram,
        'cod_amount': codAmount,
        'note': note,
      };

  factory Shipment.fromMap(Map<String, Object?> m) => Shipment(
        id: m['id'] as int?,
        createdAt: DateTime.parse(m['created_at'] as String),
        senderName: (m['sender_name'] as String?) ?? '',
        senderPhone: (m['sender_phone'] as String?) ?? '',
        senderAddress: (m['sender_address'] as String?) ?? '',
        receiverName: (m['receiver_name'] as String?) ?? '',
        receiverPhone: (m['receiver_phone'] as String?) ?? '',
        receiverAddress: (m['receiver_address'] as String?) ?? '',
        courier: (m['courier'] as String?) ?? '',
        trackingNo: (m['tracking_no'] as String?) ?? '',
        itemDesc: (m['item_desc'] as String?) ?? '',
        weightGram: (m['weight_gram'] as int?) ?? 0,
        codAmount: (m['cod_amount'] as int?) ?? 0,
        note: (m['note'] as String?) ?? '',
      );
}
