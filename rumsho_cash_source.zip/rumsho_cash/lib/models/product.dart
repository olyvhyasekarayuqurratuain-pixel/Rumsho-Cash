class Product {
  final int? id;
  final String name;
  final String barcode;
  final int price; // harga jual (Rupiah)
  final int cost; // harga modal (Rupiah)
  final int stock;
  final int minStock; // batas stok menipis
  final String? photoPath;

  const Product({
    this.id,
    required this.name,
    required this.barcode,
    required this.price,
    this.cost = 0,
    this.stock = 0,
    this.minStock = 5,
    this.photoPath,
  });

  bool get isEmpty => stock <= 0;
  bool get isLow => stock > 0 && stock <= minStock;

  Product copyWith({int? id, int? stock}) => Product(
        id: id ?? this.id,
        name: name,
        barcode: barcode,
        price: price,
        cost: cost,
        stock: stock ?? this.stock,
        minStock: minStock,
        photoPath: photoPath,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'barcode': barcode,
        'price': price,
        'cost': cost,
        'stock': stock,
        'min_stock': minStock,
        'photo_path': photoPath,
      };

  factory Product.fromMap(Map<String, Object?> m) => Product(
        id: m['id'] as int?,
        name: m['name'] as String,
        barcode: m['barcode'] as String,
        price: m['price'] as int,
        cost: (m['cost'] as int?) ?? 0,
        stock: (m['stock'] as int?) ?? 0,
        minStock: (m['min_stock'] as int?) ?? 5,
        photoPath: m['photo_path'] as String?,
      );
}
