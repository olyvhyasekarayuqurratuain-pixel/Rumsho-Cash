import 'package:shared_preferences/shared_preferences.dart';

/// Pengaturan toko & struk. Disimpan lokal (SharedPreferences), tanpa internet.
class StoreSettings {
  String name;
  String address;
  String phone;
  String logoPath;
  String footnote; // catatan kaki struk: medsos / promo
  String printerMac;
  String printerName;
  int paperMm; // 58 atau 80
  bool autoPrint; // cetak otomatis setelah bayar
  bool openDrawer; // buka cash drawer saat bayar tunai
  bool allowOversell; // izinkan jual walau stok 0

  StoreSettings({
    this.name = '',
    this.address = '',
    this.phone = '',
    this.logoPath = '',
    this.footnote = '',
    this.printerMac = '',
    this.printerName = '',
    this.paperMm = 58,
    this.autoPrint = false,
    this.openDrawer = true,
    this.allowOversell = false,
  });

  StoreSettings copy() => StoreSettings(
        name: name,
        address: address,
        phone: phone,
        logoPath: logoPath,
        footnote: footnote,
        printerMac: printerMac,
        printerName: printerName,
        paperMm: paperMm,
        autoPrint: autoPrint,
        openDrawer: openDrawer,
        allowOversell: allowOversell,
      );

  static Future<StoreSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return StoreSettings(
      name: p.getString('name') ?? '',
      address: p.getString('address') ?? '',
      phone: p.getString('phone') ?? '',
      logoPath: p.getString('logoPath') ?? '',
      footnote: p.getString('footnote') ?? '',
      printerMac: p.getString('printerMac') ?? '',
      printerName: p.getString('printerName') ?? '',
      paperMm: p.getInt('paperMm') ?? 58,
      autoPrint: p.getBool('autoPrint') ?? false,
      openDrawer: p.getBool('openDrawer') ?? true,
      allowOversell: p.getBool('allowOversell') ?? false,
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', name);
    await p.setString('address', address);
    await p.setString('phone', phone);
    await p.setString('logoPath', logoPath);
    await p.setString('footnote', footnote);
    await p.setString('printerMac', printerMac);
    await p.setString('printerName', printerName);
    await p.setInt('paperMm', paperMm);
    await p.setBool('autoPrint', autoPrint);
    await p.setBool('openDrawer', openDrawer);
    await p.setBool('allowOversell', allowOversell);
  }
}
