import 'dart:math' as math;

class SaleItem {
  final int? productId;
  final String name;
  final String barcode;
  final int qty;
  final int price;
  final int cost;

  const SaleItem({
    this.productId,
    required this.name,
    this.barcode = '',
    required this.qty,
    required this.price,
    this.cost = 0,
  });

  int get subtotal => qty * price;
  int get profit => qty * (price - cost);

  Map<String, Object?> toMap(int saleId) => {
        'sale_id': saleId,
        'product_id': productId,
        'name': name,
        'barcode': barcode,
        'qty': qty,
        'price': price,
        'cost': cost,
      };

  factory SaleItem.fromMap(Map<String, Object?> m) => SaleItem(
        productId: m['product_id'] as int?,
        name: m['name'] as String,
        barcode: (m['barcode'] as String?) ?? '',
        qty: m['qty'] as int,
        price: m['price'] as int,
        cost: (m['cost'] as int?) ?? 0,
      );
}

class Sale {
  final int? id;
  final String invoiceNo;
  final DateTime createdAt;
  final List<SaleItem> items;
  final int discount;
  final int paid;
  final String paymentMethod;
  final String customerName;
  final String note;
  final bool voided;

  const Sale({
    this.id,
    required this.invoiceNo,
    required this.createdAt,
    required this.items,
    this.discount = 0,
    required this.paid,
    this.paymentMethod = 'Tunai',
    this.customerName = '',
    this.note = '',
    this.voided = false,
  });

  int get subtotal => items.fold(0, (a, i) => a + i.subtotal);
  int get total => math.max(0, subtotal - discount);
  int get change => math.max(0, paid - total);
  int get itemCount => items.fold(0, (a, i) => a + i.qty);

  /// Laba bersih = selisih harga jual dan modal, dikurangi diskon.
  int get profit =>
      items.fold(0, (a, i) => a + i.profit) - math.min(discount, subtotal);

  Sale copyWith({int? id, String? invoiceNo, bool? voided}) => Sale(
        id: id ?? this.id,
        invoiceNo: invoiceNo ?? this.invoiceNo,
        createdAt: createdAt,
        items: items,
        discount: discount,
        paid: paid,
        paymentMethod: paymentMethod,
        customerName: customerName,
        note: note,
        voided: voided ?? this.voided,
      );

  Map<String, Object?> toMap() => {
        'invoice_no': invoiceNo,
        'created_at': createdAt.toIso8601String(),
        'subtotal': subtotal,
        'discount': discount,
        'total': total,
        'paid': paid,
        'change_amount': change,
        'payment_method': paymentMethod,
        'customer_name': customerName,
        'note': note,
        'voided': voided ? 1 : 0,
      };

  factory Sale.fromMap(Map<String, Object?> m, List<SaleItem> items) => Sale(
        id: m['id'] as int?,
        invoiceNo: m['invoice_no'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
        items: items,
        discount: (m['discount'] as int?) ?? 0,
        paid: (m['paid'] as int?) ?? 0,
        paymentMethod: (m['payment_method'] as String?) ?? 'Tunai',
        customerName: (m['customer_name'] as String?) ?? '',
        note: (m['note'] as String?) ?? '',
        voided: ((m['voided'] as int?) ?? 0) == 1,
      );
}
