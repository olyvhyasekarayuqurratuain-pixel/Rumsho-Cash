import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../db/app_database.dart';
import '../models/product.dart';
import '../models/sale.dart';
import '../models/store_settings.dart';

class CartLine {
  final Product product;
  int qty;
  CartLine(this.product, this.qty);
  int get subtotal => product.price * qty;
}

class AppState extends ChangeNotifier {
  final AppDatabase db = AppDatabase.instance;

  StoreSettings settings = StoreSettings();
  List<Product> products = [];
  final List<CartLine> cart = [];
  int discount = 0;
  String _query = '';

  Future<void> init() async {
    settings = await StoreSettings.load();
    await loadProducts();
  }

  String get query => _query;

  Future<void> loadProducts({String? query}) async {
    if (query != null) _query = query;
    products = await db.products(query: _query);
    notifyListeners();
  }

  Future<void> saveSettings(StoreSettings s) async {
    await s.save();
    settings = s;
    notifyListeners();
  }

  // ------------------------------------------------------------ KERANJANG

  int get cartSubtotal => cart.fold(0, (a, l) => a + l.subtotal);
  int get cartTotal => math.max(0, cartSubtotal - discount);
  int get cartCount => cart.fold(0, (a, l) => a + l.qty);

  /// Mengembalikan pesan error, atau null jika berhasil.
  String? addToCart(Product p) {
    final i = cart.indexWhere((l) => l.product.id == p.id);
    final current = i >= 0 ? cart[i].qty : 0;
    if (!settings.allowOversell && current + 1 > p.stock) {
      return 'Stok ${p.name} tidak cukup (sisa ${p.stock})';
    }
    if (i >= 0) {
      cart[i].qty++;
    } else {
      cart.add(CartLine(p, 1));
    }
    notifyListeners();
    return null;
  }

  String? setQty(CartLine line, int qty) {
    if (qty <= 0) {
      cart.remove(line);
      notifyListeners();
      return null;
    }
    if (!settings.allowOversell && qty > line.product.stock) {
      return 'Stok ${line.product.name} tidak cukup (sisa ${line.product.stock})';
    }
    line.qty = qty;
    notifyListeners();
    return null;
  }

  void removeLine(CartLine line) {
    cart.remove(line);
    notifyListeners();
  }

  void setDiscount(int v) {
    discount = math.max(0, v);
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    discount = 0;
    notifyListeners();
  }

  /// Menyimpan transaksi ke database lokal. Stok berkurang otomatis.
  Future<Sale> checkout({
    required String method,
    required int paid,
    String customer = '',
    String note = '',
  }) async {
    final items = cart
        .map((l) => SaleItem(
              productId: l.product.id,
              name: l.product.name,
              barcode: l.product.barcode,
              qty: l.qty,
              price: l.product.price,
              cost: l.product.cost,
            ))
        .toList();
    final sale = Sale(
      invoiceNo: '',
      createdAt: DateTime.now(),
      items: items,
      discount: math.min(discount, cartSubtotal),
      paid: paid,
      paymentMethod: method,
      customerName: customer,
      note: note,
    );
    final saved = await db.insertSale(sale);
    cart.clear();
    discount = 0;
    await loadProducts();
    return saved;
  }
}
