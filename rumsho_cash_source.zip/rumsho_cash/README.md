# Rumsho Cash

Aplikasi kasir **offline** untuk Android (Flutter). Semua data tersimpan di perangkat (SQLite), tanpa akun, tanpa iklan, tanpa langganan.

> **Status:** kode sumber lengkap, tetapi **belum pernah dikompilasi atau dijalankan** (lingkungan tempat kode ini ditulis tidak punya Flutter SDK dan internet). Kemungkinan ada beberapa error kecil saat build pertama (nama parameter, versi paket). Lihat bagian "Kalau build error".

## Cara build

Butuh [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.22 atau lebih baru) dan Android Studio / Android SDK.

```bash
cd rumsho_cash

# 1. Buat folder android/ (hanya sekali)
flutter create . --platforms=android --org id.rumsho --project-name rumsho_cash

# 2. Pakai AndroidManifest berisi izin Bluetooth & kamera
cp android_setup/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# 3. Hapus test bawaan (merujuk ke aplikasi contoh)
rm -f test/widget_test.dart

# 4. Unduh paket & jalankan di HP (aktifkan USB debugging)
flutter pub get
flutter run

# 5. Buat APK untuk dibagikan / dijual
flutter build apk --release --split-per-abi
```

APK ada di `build/app/outputs/flutter-apk/`. Untuk rilis resmi, buat keystore dan tanda tangani APK ([panduan](https://docs.flutter.dev/deployment/android#sign-the-app)).

### Kalau build error
- Error versi `minSdk`: di `android/app/build.gradle(.kts)` set `minSdk = 21` (atau 24).
- Konflik versi paket: jalankan `flutter pub upgrade`.
- API paket berubah (printer, scanner, Excel): cek nama parameter di changelog paket terkait. Paket paling sensitif: `mobile_scanner`, `print_bluetooth_thermal`, `esc_pos_utils_plus`, `excel`.

## Fitur

| Fitur | Di mana |
|---|---|
| Struk digital + cetak struk kertas (thermal Bluetooth) | `receipt_screen.dart`, `printer_service.dart` |
| Bagikan struk digital via email / chat | tombol **Bagikan** di layar struk (gambar PNG lewat menu bagikan Android) |
| Logo, nama, alamat toko di struk | Menu > Toko & Struk |
| Produk: nama, foto, harga, barcode/QR | tab Produk, `product_form_screen.dart` |
| Catatan kaki struk (medsos / promo) | Menu > Toko & Struk |
| Transaksi tercatat otomatis (penyimpanan lokal) | `app_database.dart` (SQLite) |
| Generate barcode / QR, cetak label | form produk: tombol generate, pilih Barcode/QR, **Cetak label** |
| Baca barcode / QR lewat kamera | `scanner_screen.dart` (kasir, produk, stok) |
| Catat stok persediaan | Menu > Stok Barang (restock, kurangi, stok opname, riwayat) |
| Cetak resi pengiriman | Menu > Resi Pengiriman (bisa juga dari struk) |
| Profit / keuntungan | harga modal dan harga jual per produk, tampil di tab Laporan |
| Cash drawer | otomatis terbuka saat bayar tunai, atau tombol buka laci |
| Laporan lengkap + export Excel | tab Laporan: per hari, produk terlaris, metode bayar, export .xlsx |
| Tanpa internet | aplikasi **tidak meminta izin INTERNET** sama sekali |
| Tanpa iklan | tidak ada SDK iklan |

## Catatan penting

**Printer thermal.** Pairing printer dulu di Pengaturan Android > Bluetooth (PIN umumnya `0000` atau `1234`), lalu pilih di Menu > Printer Bluetooth. Mendukung printer ESC/POS berbasis Bluetooth Classic (SPP), yaitu mayoritas printer thermal 58 mm / 80 mm. Printer yang hanya BLE tidak didukung oleh paket ini. Teks struk dicetak sebagai ASCII, jadi karakter beraksen akan tampil sebagai `?`.

**Cash drawer.** Sambungkan laci ke port RJ11 di printer. Aplikasi mengirim perintah ESC/POS ke pin 2. Jika laci Anda tidak terbuka, laci tersebut kemungkinan memakai pin 5 (ubah `g.drawer()` menjadi `g.drawer(pin: PosDrawer.pin5)` di `printer_service.dart`).

**Barcode di kertas 58 mm.** Barcode dicetak sebagai gambar. Kode panjang (di atas sekitar 14 karakter) bisa sulit terbaca; gunakan QR atau kode lebih pendek. Kode otomatis (`RC` + 8 angka) aman.

**Export Excel.** File dibuat di perangkat lalu dibuka lewat menu bagikan, sehingga bisa disimpan ke Files / Drive atau dikirim ke WhatsApp.

**Struk digital.** Satu-satunya langkah yang butuh internet adalah saat aplikasi tujuan (WhatsApp, Gmail, dll) mengirim pesan. Aplikasi ini sendiri tetap offline.

## Belum ada (saran pengembangan)

- **Cadangan & pemulihan data.** Data hanya ada di satu perangkat; kalau HP hilang atau di-reset, data ikut hilang. Fitur backup ke file sangat disarankan sebelum dijual.
- **"Sekali bayar berlaku selamanya".** Ini keputusan distribusi, bukan kode: bisa lewat aplikasi berbayar di Play Store, atau menambahkan aktivasi lisensi offline.
- Retur / refund sebagian, banyak kasir / hak akses, pajak (PPN), pelanggan tetap, dan dukungan iPhone.
- Tes otomatis (unit & widget test).

## Struktur

```
lib/
  main.dart
  models/      product, sale, shipment, store_settings
  db/          app_database.dart  (SQLite: produk, transaksi, stok, resi)
  state/       app_state.dart     (keranjang, pengaturan, checkout)
  services/    printer_service, barcode_raster, share_service, export_service
  widgets/     cart_panel (+ dialog bayar), receipt_view, common
  screens/     kasir, produk, stok, laporan, riwayat, resi, pengaturan, printer, scanner
android_setup/AndroidManifest.xml
```
